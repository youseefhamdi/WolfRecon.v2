#!/bin/bash

# Wolf Recon MCP - Tool Installation Script
# Installs reconnaissance tools for the distributed platform

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m'

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_header() {
    echo -e "${PURPLE}[WOLF]${NC} $1"
}

# Check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Install Go tools
install_go_tool() {
    local tool=$1
    local repo=$2
    
    log_info "Installing $tool..."
    if command_exists "$tool"; then
        log_success "$tool already installed"
        return 0
    fi
    
    if command_exists "go"; then
        go install "$repo@latest"
        if command_exists "$tool"; then
            log_success "$tool installed successfully"
        else
            log_error "Failed to install $tool"
            return 1
        fi
    else
        log_error "Go not found, cannot install $tool"
        return 1
    fi
}

# Install system packages
install_system_packages() {
    log_info "Installing system packages..."
    
    if command_exists "apt-get"; then
        # Debian/Ubuntu
        sudo apt-get update
        sudo apt-get install -y nmap whatweb python3 python3-pip curl wget git
    elif command_exists "yum"; then
        # CentOS/RHEL
        sudo yum install -y nmap python3 python3-pip curl wget git
    elif command_exists "pacman"; then
        # Arch Linux
        sudo pacman -S --noconfirm nmap python python-pip curl wget git
    elif command_exists "brew"; then
        # macOS
        brew install nmap python3 curl wget git
    else
        log_warning "Unknown package manager, please install nmap, python3, curl, wget, git manually"
    fi
}

# Install Python tools
install_python_tools() {
    log_info "Installing Python reconnaissance tools..."
    
    if command_exists "python3" && command_exists "pip3"; then
        # Install sublist3r
        if ! command_exists "sublist3r"; then
            log_info "Installing Sublist3r..."
            pip3 install sublist3r
        fi
        
        # Install other Python tools
        pip3 install requests dnspython
    else
        log_warning "Python3/pip3 not found, skipping Python tools"
    fi
}

# Install reconnaissance tools
install_recon_tools() {
    log_header "Installing reconnaissance tools..."
    
    # Go-based tools
    install_go_tool "subfinder" "github.com/projectdiscovery/subfinder/v2/cmd/subfinder"
    install_go_tool "assetfinder" "github.com/tomnomnom/assetfinder"
    install_go_tool "amass" "github.com/OWASP/Amass/v3/..."
    install_go_tool "ffuf" "github.com/ffuf/ffuf"
    install_go_tool "httpx" "github.com/projectdiscovery/httpx/cmd/httpx"
    install_go_tool "nuclei" "github.com/projectdiscovery/nuclei/v2/cmd/nuclei"
    install_go_tool "subdog" "github.com/d4rckh/subdog"
    install_go_tool "knockpy" "github.com/guelfoweb/knock"
    
    # Install system packages
    install_system_packages
    
    # Install Python tools
    install_python_tools
}

# Setup wordlists
setup_wordlists() {
    log_header "Setting up wordlists..."
    
    mkdir -p wordlists
    cd wordlists
    
    # Download common wordlists
    if [ ! -f "subdomains.txt" ]; then
        log_info "Downloading subdomain wordlist..."
        curl -s "https://raw.githubusercontent.com/danielmiessler/SecLists/master/Discovery/DNS/subdomains-top1million-20000.txt" -o subdomains.txt
    fi
    
    if [ ! -f "directories.txt" ]; then
        log_info "Downloading directory wordlist..."
        curl -s "https://raw.githubusercontent.com/danielmiessler/SecLists/master/Discovery/Web-Content/directory-list-2.3-small.txt" -o directories.txt
    fi
    
    cd ..
    log_success "Wordlists setup completed"
}

# Verify installations
verify_tools() {
    log_header "Verifying tool installations..."
    
    tools=("subfinder" "assetfinder" "amass" "ffuf" "nmap" "whatweb")
    installed_count=0
    total_count=${#tools[@]}
    
    for tool in "${tools[@]}"; do
        if command_exists "$tool"; then
            log_success "$tool: installed"
            ((installed_count++))
        else
            log_warning "$tool: not found"
        fi
    done
    
    echo ""
    log_info "Installation summary: $installed_count/$total_count tools installed"
    
    if [ $installed_count -gt 0 ]; then
        log_success "Wolf Recon MCP tools setup completed!"
        echo ""
        echo "Next steps:"
        echo "  1. make build          # Build the project"
        echo "  2. ./run.sh controller # Start controller"
        echo "  3. ./run.sh agent      # Start agent"
    else
        log_error "No tools were installed successfully"
        exit 1
    fi
}

# Main installation function
main() {
    echo ""
    log_header "Wolf Recon MCP - Tool Installation"
    echo "======================================"
    echo ""
    
    # Check prerequisites
    if ! command_exists "go"; then
        log_error "Go is required but not installed. Please install Go 1.21+ first."
        exit 1
    fi
    
    log_info "Go version: $(go version)"
    echo ""
    
    # Install tools
    install_recon_tools
    
    # Setup wordlists
    setup_wordlists
    
    # Verify installations
    verify_tools
}

# Run main function
main "$@"