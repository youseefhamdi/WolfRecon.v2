package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"os/signal"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"syscall"
	"time"
	
	"wolf-recon-mcp/internal/agent"
	"wolf-recon-mcp/internal/mcp"
	"wolf-recon-mcp/internal/models"
	"wolf-recon-mcp/pkg/utils"
	"github.com/sirupsen/logrus"
	"github.com/google/uuid"
)

var (
	version   = "2.5"
	buildDate = "unknown"
	
	// Command line flags
	serverAddr = flag.String("server", "localhost:8080", "Controller server address")
	agentName  = flag.String("name", "", "Agent name (auto-generated if empty)")
	workDir    = flag.String("workdir", "./agent-work", "Working directory")
	maxTasks   = flag.Int("max-tasks", 5, "Maximum concurrent tasks")
	config     = flag.String("config", "configs/agent.yaml", "Configuration file path")
	logLevel   = flag.String("log", "info", "Log level (debug, info, warn, error)")
	logFormat  = flag.String("log-format", "text", "Log format (text, json)")
	tools      = flag.String("tools", "", "Comma-separated list of enabled tools")
	daemon     = flag.Bool("daemon", false, "Run in daemon mode")
	tags       = flag.String("tags", "", "Comma-separated list of agent tags")
)

// Agent represents a reconnaissance agent
type Agent struct {
	id            string
	name          string
	version       string
	client        *mcp.MCPClient
	scanner       *agent.Scanner
	logger        *logrus.Logger
	workDir       string
	maxTasks      int
	currentTasks  map[string]*TaskExecution
	tasksMux      sync.RWMutex
	ctx           context.Context
	cancel        context.CancelFunc
	stats         *AgentStats
	statsMux      sync.RWMutex
	capabilities  []string
	tags          []string
}

// TaskExecution tracks running task execution
type TaskExecution struct {
	TaskID    string
	Type      string
	Target    string
	StartTime time.Time
	Progress  float64
	Cancel    context.CancelFunc
}

// AgentStats holds agent statistics
type AgentStats struct {
	StartTime       time.Time `json:"start_time"`
	TotalTasks      int       `json:"total_tasks"`
	CompletedTasks  int       `json:"completed_tasks"`
	FailedTasks     int       `json:"failed_tasks"`
	CurrentTasks    int       `json:"current_tasks"`
	MessagesHandled int       `json:"messages_handled"`
	LastTaskTime    time.Time `json:"last_task_time"`
}

func main() {
	flag.Parse()
	
	// Initialize logger
	logger := utils.NewLogger(*logLevel)
	if *logFormat == "json" {
		logger.SetFormatter(&logrus.JSONFormatter{})
	}
	
	// Print banner
	utils.PrintAgentBanner()
	utils.PrintSystemInfo()
	
	// Generate agent name if not provided
	if *agentName == "" {
		hostname, _ := os.Hostname()
		if hostname == "" {
			hostname = "unknown"
		}
		*agentName = fmt.Sprintf("wolf-agent-%s", hostname)
	}
	
	// Display configuration
	fmt.Printf("📋 Agent Configuration:\n")
	fmt.Printf("   Name: %s\n", *agentName)
	fmt.Printf("   Server: %s\n", *serverAddr)
	fmt.Printf("   Work Directory: %s\n", *workDir)
	fmt.Printf("   Max Tasks: %d\n", *maxTasks)
	fmt.Printf("   Version: %s\n", version)
	fmt.Printf("   Build Date: %s\n", buildDate)
	fmt.Println()
	
	// Create work directory
	absWorkDir, err := filepath.Abs(*workDir)
	if err != nil {
		logger.Fatalf("Failed to get absolute work directory: %v", err)
	}
	
	if err := os.MkdirAll(absWorkDir, 0755); err != nil {
		logger.Fatalf("Failed to create work directory: %v", err)
	}
	
	// Create agent
	agentInstance := NewAgent(*serverAddr, *agentName, absWorkDir, *maxTasks, logger)
	
	// Setup signal handling
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
	
	// Start agent
	go func() {
		logger.Infof("Starting Wolf Recon Agent: %s", agentInstance.name)
		if err := agentInstance.Start(); err != nil {
			logger.Fatalf("Failed to start agent: %v", err)
		}
	}()
	
	// Start background services
	go agentInstance.statusUpdater()
	go agentInstance.healthMonitor()
	
	if !*daemon {
		utils.PrintWelcomeMessage("agent")
		fmt.Printf("📡 Connecting to controller at %s...\n", *serverAddr)
		fmt.Println("🔧 Discovering available reconnaissance tools...")
		fmt.Println()
	}
	
	// Wait for shutdown signal
	<-sigChan
	logger.Info("Received shutdown signal, stopping agent...")
	agentInstance.Stop()
	logger.Info("Agent stopped successfully")
}

// NewAgent creates a new agent instance
func NewAgent(serverAddr, agentName, workDir string, maxTasks int, logger *logrus.Logger) *Agent {
	agentID := uuid.New().String()
	outputDir := filepath.Join(workDir, "output", agentID)
	
	// Create output directory
	os.MkdirAll(outputDir, 0755)
	
	ctx, cancel := context.WithCancel(context.Background())
	
	// Parse tags
	var agentTags []string
	if *tags != "" {
		agentTags = strings.Split(*tags, ",")
		for i, tag := range agentTags {
			agentTags[i] = strings.TrimSpace(tag)
		}
	}
	
	agentInstance := &Agent{
		id:           agentID,
		name:         agentName,
		version:      version,
		client:       mcp.NewClient(serverAddr, agentID, agentName, logger),
		scanner:      agent.NewScanner(workDir, outputDir, logger),
		logger:       logger,
		workDir:      workDir,
		maxTasks:     maxTasks,
		currentTasks: make(map[string]*TaskExecution),
		ctx:          ctx,
		cancel:       cancel,
		stats: &AgentStats{
			StartTime: time.Now(),
		},
		tags: agentTags,
	}
	
	// Get capabilities from scanner
	agentInstance.capabilities = agentInstance.scanner.GetAvailableTools()
	
	// Filter tools if specified
	if *tools != "" {
		requestedTools := strings.Split(*tools, ",")
		var filteredCapabilities []string
		for _, tool := range requestedTools {
			tool = strings.TrimSpace(tool)
			for _, capability := range agentInstance.capabilities {
				if capability == tool {
					filteredCapabilities = append(filteredCapabilities, capability)
					break
				}
			}
		}
		agentInstance.capabilities = filteredCapabilities
	}
	
	// Setup message handlers
	agentInstance.setupHandlers()
	
	return agentInstance
}

// setupHandlers registers message handlers
func (a *Agent) setupHandlers() {
	a.client.RegisterHandler(mcp.MessageTaskAssignment, a.handleTaskAssignment)
	a.client.RegisterHandler(mcp.MessageTaskCancel, a.handleTaskCancel)
	a.client.RegisterHandler(mcp.MessagePing, a.handlePing)
	a.client.RegisterHandler(mcp.MessageShutdown, a.handleShutdown)
}

// Start starts the agent
func (a *Agent) Start() error {
	a.logger.Infof("Starting agent %s (%s)", a.name, a.id)
	
	// Display tool capabilities
	if len(a.capabilities) > 0 {
		utils.PrintToolList(a.capabilities)
	} else {
		utils.PrintWarningMessage("No reconnaissance tools found", []string{
			"Run './install-tools.sh' to install tools",
			"Check your PATH environment variable",
			"Verify tool installations manually",
		})
	}
	
	// Enable auto-reconnection
	a.client.AutoReconnect(5 * time.Second)
	
	// Connect to controller
	if err := a.client.Connect(); err != nil {
		return fmt.Errorf("failed to connect to controller: %v", err)
	}
	
	// Send initial agent registration
	a.sendAgentInfo()
	
	utils.PrintConnectionStatus("connected", map[string]interface{}{
		"server":       *serverAddr,
		"agent_id":     a.id[:8] + "...",
		"capabilities": len(a.capabilities),
	})
	
	// Keep running until context is canceled
	<-a.ctx.Done()
	return nil
}

// Stop gracefully stops the agent
func (a *Agent) Stop() {
	a.logger.Info("Stopping agent...")
	
	// Cancel all running tasks
	a.tasksMux.Lock()
	for _, task := range a.currentTasks {
		task.Cancel()
	}
	a.tasksMux.Unlock()
	
	// Disconnect from controller
	a.client.Disconnect()
	
	// Cancel context
	a.cancel()
	
	a.logger.Info("Agent stopped")
}

// Message handlers

func (a *Agent) handleTaskAssignment(client *mcp.Client, msg *mcp.Message) error {
	a.logger.WithField("message_id", msg.ID).Info("Received task assignment")
	
	// Parse task assignment
	payload, exists := msg.GetPayload("task")
	if !exists {
		return fmt.Errorf("no task in payload")
	}
	
	taskData, err := json.Marshal(payload)
	if err != nil {
		return fmt.Errorf("failed to marshal task: %v", err)
	}
	
	var assignment mcp.TaskAssignment
	if err := json.Unmarshal(taskData, &assignment); err != nil {
		return fmt.Errorf("failed to unmarshal task assignment: %v", err)
	}
	
	// Check if we can handle more tasks
	a.tasksMux.RLock()
	currentTaskCount := len(a.currentTasks)
	a.tasksMux.RUnlock()
	
	if currentTaskCount >= a.maxTasks {
		// Send busy response
		response := mcp.NewMessage(mcp.MessageError, a.id)
		response.ResponseTo = msg.ID
		response.SetPayload("error", mcp.ErrorPayload{
			Code:        "AGENT_BUSY",
			Message:     "Agent at maximum capacity",
			TaskID:      assignment.TaskID,
			Timestamp:   time.Now().Unix(),
			Recoverable: true,
		})
		
		return a.client.SendMessage(response)
	}
	
	// Check if we support this task type
	supported := false
	for _, capability := range a.capabilities {
		if capability == assignment.Type {
			supported = true
			break
		}
	}
	
	if !supported {
		response := mcp.NewMessage(mcp.MessageError, a.id)
		response.ResponseTo = msg.ID
		response.SetPayload("error", mcp.ErrorPayload{
			Code:        "UNSUPPORTED_TASK",
			Message:     fmt.Sprintf("Task type %s not supported", assignment.Type),
			TaskID:      assignment.TaskID,
			Timestamp:   time.Now().Unix(),
			Recoverable: false,
		})
		
		return a.client.SendMessage(response)
	}
	
	// Send acknowledgment
	ack := mcp.NewMessage(mcp.MessageAck, a.id)
	ack.ResponseTo = msg.ID
	ack.SetPayload("task_id", assignment.TaskID)
	ack.SetPayload("status", "accepted")
	
	if err := a.client.SendMessage(ack); err != nil {
		a.logger.Errorf("Failed to send acknowledgment: %v", err)
	}
	
	// Execute task asynchronously
	go a.executeTask(&assignment)
	
	// Update stats
	a.statsMux.Lock()
	a.stats.TotalTasks++
	a.stats.CurrentTasks++
	a.stats.MessagesHandled++
	a.statsMux.Unlock()
	
	return nil
}

func (a *Agent) handleTaskCancel(client *mcp.Client, msg *mcp.Message) error {
	taskID, exists := msg.GetPayloadString("task_id")
	if !exists {
		return fmt.Errorf("no task_id in cancel message")
	}
	
	a.logger.WithField("task_id", taskID).Info("Received task cancellation")
	
	a.tasksMux.Lock()
	if execution, exists := a.currentTasks[taskID]; exists {
		execution.Cancel()
		delete(a.currentTasks, taskID)
		a.logger.WithField("task_id", taskID).Info("Task canceled")
	}
	a.tasksMux.Unlock()
	
	// Send cancellation acknowledgment
	response := mcp.NewMessage(mcp.MessageAck, a.id)
	response.ResponseTo = msg.ID
	response.SetPayload("task_id", taskID)
	response.SetPayload("status", "canceled")
	
	return a.client.SendMessage(response)
}

func (a *Agent) handlePing(client *mcp.Client, msg *mcp.Message) error {
	a.logger.Debug("Received ping")
	
	response := mcp.NewMessage(mcp.MessagePong, a.id)
	response.ResponseTo = msg.ID
	response.SetPayload("timestamp", time.Now().Unix())
	response.SetPayload("agent_id", a.id)
	response.SetPayload("status", "healthy")
	
	return a.client.SendMessage(response)
}

func (a *Agent) handleShutdown(client *mcp.Client, msg *mcp.Message) error {
	a.logger.Info("Received shutdown command from controller")
	
	// Send acknowledgment
	response := mcp.NewMessage(mcp.MessageAck, a.id)
	response.ResponseTo = msg.ID
	response.SetPayload("status", "shutting_down")
	
	a.client.SendMessage(response)
	
	// Initiate graceful shutdown
	go func() {
		time.Sleep(1 * time.Second)
		a.Stop()
		os.Exit(0)
	}()
	
	return nil
}

// Task execution

func (a *Agent) executeTask(assignment *mcp.TaskAssignment) {
	taskCtx, cancel := context.WithTimeout(a.ctx, time.Duration(assignment.Timeout)*time.Second)
	defer cancel()
	
	startTime := time.Now()
	
	// Create task execution tracker
	execution := &TaskExecution{
		TaskID:    assignment.TaskID,
		Type:      assignment.Type,
		Target:    assignment.Target,
		StartTime: startTime,
		Progress:  0.0,
		Cancel:    cancel,
	}
	
	a.tasksMux.Lock()
	a.currentTasks[assignment.TaskID] = execution
	a.tasksMux.Unlock()
	
	defer func() {
		a.tasksMux.Lock()
		delete(a.currentTasks, assignment.TaskID)
		a.tasksMux.Unlock()
		
		a.statsMux.Lock()
		a.stats.CurrentTasks--
		a.stats.LastTaskTime = time.Now()
		a.statsMux.Unlock()
	}()
	
	// Send task started notification
	a.sendTaskStatus(assignment.TaskID, "running", "", nil)
	
	a.logger.WithFields(logrus.Fields{
		"task_id":   assignment.TaskID,
		"task_type": assignment.Type,
		"target":    assignment.Target,
		"timeout":   assignment.Timeout,
	}).Info("Starting task execution")
	
	// Execute the reconnaissance scan
	taskType := models.TaskType(assignment.Type)
	result := a.scanner.RunTool(taskType, assignment.Target, assignment.Timeout)
	
	// Handle the result
	if result.Error != nil {
		a.sendTaskStatus(assignment.TaskID, "failed", result.Error.Error(), result)
		a.logger.WithFields(logrus.Fields{
			"task_id": assignment.TaskID,
			"error":   result.Error,
		}).Error("Task execution failed")
		
		a.statsMux.Lock()
		a.stats.FailedTasks++
		a.statsMux.Unlock()
	} else {
		a.sendTaskStatus(assignment.TaskID, "completed", "", result)
		a.logger.WithFields(logrus.Fields{
			"task_id":  assignment.TaskID,
			"count":    result.Count,
			"duration": result.Duration,
		}).Info("Task execution completed successfully")
		
		a.statsMux.Lock()
		a.stats.CompletedTasks++
		a.statsMux.Unlock()
	}
}

func (a *Agent) sendTaskStatus(taskID, status, errorMsg string, result *models.ScanResult) {
	msg := mcp.NewMessage(mcp.MessageTaskResult, a.id)
	
	payload := mcp.TaskResultPayload{
		TaskID:    taskID,
		Status:    status,
		Error:     errorMsg,
		StartTime: time.Now().Unix(),
		EndTime:   time.Now().Unix(),
	}
	
	if result != nil {
		payload.Subdomains = result.Subdomains
		payload.IPs = result.IPs
		payload.URLs = result.URLs
		payload.Count = result.Count
		payload.Duration = result.Duration.Milliseconds()
		payload.OutputFile = result.OutputFile
		payload.Screenshots = result.Screenshots
		payload.Metadata = result.Metadata
	}
	
	msg.SetPayload("result", payload)
	
	if err := a.client.SendMessage(msg); err != nil {
		a.logger.WithError(err).Error("Failed to send task result")
	}
}

// Background services

func (a *Agent) sendAgentInfo() {
	msg := mcp.NewMessage(mcp.MessageStatusUpdate, a.id)
	
	a.tasksMux.RLock()
	currentTasks := len(a.currentTasks)
	a.tasksMux.RUnlock()
	
	info := mcp.AgentStatusPayload{
		AgentID:        a.id,
		Name:           a.name,
		Status:         string(models.AgentOnline),
		Version:        a.version,
		Capabilities:   a.capabilities,
		MaxTasks:       a.maxTasks,
		CurrentTasks:   currentTasks,
		CompletedTasks: a.stats.CompletedTasks,
		FailedTasks:    a.stats.FailedTasks,
		Uptime:         int64(time.Since(a.stats.StartTime).Seconds()),
		LastActivity:   time.Now().Unix(),
		Platform:       runtime.GOOS,
		Architecture:   runtime.GOARCH,
		Tags:           a.tags,
	}
	
	msg.SetPayload("agent_info", info)
	
	if err := a.client.SendMessage(msg); err != nil {
		a.logger.WithError(err).Error("Failed to send agent info")
	}
}

func (a *Agent) statusUpdater() {
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()
	
	for {
		select {
		case <-a.ctx.Done():
			return
		case <-ticker.C:
			if a.client.IsConnected() {
				a.sendAgentInfo()
			}
		}
	}
}

func (a *Agent) healthMonitor() {
	ticker := time.NewTicker(5 * time.Minute)
	defer ticker.Stop()
	
	for {
		select {
		case <-a.ctx.Done():
			return
		case <-ticker.C:
			a.performHealthCheck()
		}
	}
}

func (a *Agent) performHealthCheck() {
	// Simple health check - clean up old files
	if err := a.scanner.CleanupOldResults(24 * time.Hour); err != nil {
		a.logger.WithError(err).Warn("Failed to cleanup old files")
	}
}