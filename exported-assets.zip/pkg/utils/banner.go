package utils

import (
	"fmt"
	"os"
	"runtime"
	"strings"
	"time"
	
	"github.com/sirupsen/logrus"
)

// NewLogger creates a new logger instance
func NewLogger(level string) *logrus.Logger {
	logger := logrus.New()
	logger.SetOutput(os.Stdout)
	
	switch level {
	case "debug":
		logger.SetLevel(logrus.DebugLevel)
	case "info":
		logger.SetLevel(logrus.InfoLevel)
	case "warn":
		logger.SetLevel(logrus.WarnLevel)
	case "error":
		logger.SetLevel(logrus.ErrorLevel)
	default:
		logger.SetLevel(logrus.InfoLevel)
	}
	
	return logger
}

// PrintControllerBanner prints the controller banner
func PrintControllerBanner() {
	fmt.Print("\033[36m")
	fmt.Print("              __\n")
	fmt.Print("   __      __/ _\\\n")
	fmt.Print("   \\ \\ /\\ / /\\ \\\n")
	fmt.Print("    \\ V  V /  _\\\n")
	fmt.Print("     \\_/\\_/\n")
	fmt.Print("\n")
	fmt.Print("      _ __ ___  ___ ___  _ __\n")
	fmt.Print("     | '__/ _ \\/ __/ _ \\| '_ \\\n")
	fmt.Print("     | | |  __/ (_| (_) | | | |\n")
	fmt.Print("     |_|  \\___|\\___\\___/|_| |_|\n")
	fmt.Print("\n")
	fmt.Print("        Wolf Recon MCP v2.5\n")
	fmt.Print("          Controller Mode\n")
	fmt.Print("     Advanced Reconnaissance Platform\n")
	fmt.Print("\033[0m\n")
}

// PrintAgentBanner prints the agent banner
func PrintAgentBanner() {
	fmt.Print("\033[35m")
	fmt.Print("              __\n")
	fmt.Print("   __      __/ _\\\n")
	fmt.Print("   \\ \\ /\\ / /\\ \\\n")
	fmt.Print("    \\ V  V /  _\\\n")
	fmt.Print("     \\_/\\_/\n")
	fmt.Print("\n")
	fmt.Print("      __ _  __ _  ___ _ __ | |_\n")
	fmt.Print("     / _` |/ _` |/ _ \\ '_ \\| __|\n")
	fmt.Print("    | (_| | (_| |  __/ | | | |_\n")
	fmt.Print("     \\__,_|\\__, |\\___|_| |_|\\__|\n")
	fmt.Print("           |___/\n")
	fmt.Print("\n")
	fmt.Print("        Wolf Recon MCP v2.5\n")
	fmt.Print("            Agent Mode\n")
	fmt.Print("     Advanced Reconnaissance Platform\n")
	fmt.Print("\033[0m\n")
}

// PrintSystemInfo prints system information
func PrintSystemInfo() {
	fmt.Printf("\033[34m📊 System Information:\033[0m\n")
	fmt.Printf("   OS: %s\n", runtime.GOOS)
	fmt.Printf("   Architecture: %s\n", runtime.GOARCH)
	fmt.Printf("   Go Version: %s\n", runtime.Version())
	fmt.Printf("   CPUs: %d\n", runtime.NumCPU())
	fmt.Printf("   Timestamp: %s\n", time.Now().Format("2006-01-02 15:04:05"))
	fmt.Println()
}

// PrintConnectionStatus prints connection status
func PrintConnectionStatus(status string, info map[string]interface{}) {
	if status == "connected" {
		fmt.Print("\033[32m🌐 Connection Status: CONNECTED\033[0m\n")
	} else {
		fmt.Print("\033[31m🌐 Connection Status: DISCONNECTED\033[0m\n")
	}
	
	for key, value := range info {
		fmt.Printf("   %s: %v\n", strings.Title(key), value)
	}
	fmt.Println()
}

// PrintToolList prints available tools
func PrintToolList(tools []string) {
	if len(tools) == 0 {
		fmt.Print("\033[33m⚠️  No tools available\033[0m\n")
		return
	}
	
	fmt.Printf("\033[32m🔧 Available Tools (%d):\033[0m\n", len(tools))
	for i, tool := range tools {
		if i > 0 && i%4 == 0 {
			fmt.Println()
		}
		fmt.Printf("   ✅ %-12s", tool)
	}
	fmt.Println()
	fmt.Println()
}

// PrintWelcomeMessage prints welcome message
func PrintWelcomeMessage(mode string) {
	fmt.Printf("\033[33m🎉 Wolf Recon MCP %s Started Successfully!\033[0m\n", strings.Title(mode))
	fmt.Println()
}

// PrintWarningMessage prints warning with suggestions
func PrintWarningMessage(message string, suggestions []string) {
	fmt.Printf("\033[33m⚠️  %s\033[0m\n", message)
	if len(suggestions) > 0 {
		fmt.Println("💡 Suggestions:")
		for _, suggestion := range suggestions {
			fmt.Printf("   • %s\n", suggestion)
		}
	}
	fmt.Println()
}

// PrintHeader prints a formatted header
func PrintHeader(title string) {
	fmt.Printf("\033[36m🔍 %s\033[0m\n", title)
	fmt.Println(strings.Repeat("=", len(title)+4))
}

// ClearScreen clears the terminal screen
func ClearScreen() {
	fmt.Print("\033[2J")
	fmt.Print("\033[H")
}

// MoveCursor moves cursor to specific position
func MoveCursor(row, col int) {
	fmt.Printf("\033[%d;%dH", row, col)
}