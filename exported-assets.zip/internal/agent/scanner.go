package agent

import (
	"bufio"
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"time"
	
	"wolf-recon-mcp/internal/models"
	"github.com/sirupsen/logrus"
)

// Scanner handles reconnaissance tool execution
type Scanner struct {
	workDir     string
	outputDir   string
	logger      *logrus.Logger
	tools       map[string]*ToolInfo
	toolPaths   map[string]string
}

// ToolInfo contains information about a reconnaissance tool
type ToolInfo struct {
	Name        string
	Path        string
	Version     string
	Available   bool
	LastChecked time.Time
}

// NewScanner creates a new scanner instance
func NewScanner(workDir, outputDir string, logger *logrus.Logger) *Scanner {
	scanner := &Scanner{
		workDir:   workDir,
		outputDir: outputDir,
		logger:    logger,
		tools:     make(map[string]*ToolInfo),
		toolPaths: make(map[string]string),
	}
	
	scanner.discoverTools()
	return scanner
}

// discoverTools discovers available reconnaissance tools
func (s *Scanner) discoverTools() {
	toolNames := []string{
		"subfinder", "assetfinder", "amass", "ffuf", "sublist3r",
		"subdog", "sudomy", "dnscan", "nmap", "whatweb", "knockpy", "bbot",
	}
	
	s.logger.Info("Discovering available reconnaissance tools...")
	
	for _, tool := range toolNames {
		if path := s.findTool(tool); path != "" {
			version := s.getToolVersion(tool, path)
			s.tools[tool] = &ToolInfo{
				Name:        tool,
				Path:        path,
				Version:     version,
				Available:   true,
				LastChecked: time.Now(),
			}
			s.toolPaths[tool] = path
			s.logger.WithFields(logrus.Fields{
				"tool":    tool,
				"path":    path,
				"version": version,
			}).Debug("Tool discovered")
		} else {
			s.tools[tool] = &ToolInfo{
				Name:        tool,
				Available:   false,
				LastChecked: time.Now(),
			}
			s.logger.WithField("tool", tool).Debug("Tool not found")
		}
	}
}

// findTool finds the path to a tool
func (s *Scanner) findTool(toolName string) string {
	// Check common paths
	commonPaths := []string{
		"/usr/local/bin/",
		"/usr/bin/",
		"/opt/",
		filepath.Join(os.Getenv("HOME"), "go", "bin") + "/",
		filepath.Join(os.Getenv("HOME"), ".local", "bin") + "/",
		"./tools/",
	}
	
	// First try PATH
	if path, err := exec.LookPath(toolName); err == nil {
		return path
	}
	
	// Then try common paths
	for _, basePath := range commonPaths {
		fullPath := filepath.Join(basePath, toolName)
		if _, err := os.Stat(fullPath); err == nil {
			return fullPath
		}
	}
	
	return ""
}

// getToolVersion gets version information for a tool
func (s *Scanner) getToolVersion(toolName, toolPath string) string {
	versionArgs := map[string][]string{
		"subfinder":   {"-version"},
		"assetfinder": {"-h"},
		"amass":       {"-version"},
		"ffuf":        {"-V"},
		"nmap":        {"--version"},
		"whatweb":     {"--version"},
	}
	
	args, exists := versionArgs[toolName]
	if !exists {
		args = []string{"--version"}
	}
	
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	
	cmd := exec.CommandContext(ctx, toolPath, args...)
	output, err := cmd.Output()
	if err != nil {
		return "unknown"
	}
	
	lines := strings.Split(string(output), "\n")
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if line != "" && !strings.HasPrefix(line, "Usage:") {
			if len(line) > 50 {
				line = line[:50] + "..."
			}
			return line
		}
	}
	
	return "detected"
}

// GetAvailableTools returns list of available tools
func (s *Scanner) GetAvailableTools() []string {
	var available []string
	for name, tool := range s.tools {
		if tool.Available {
			available = append(available, name)
		}
	}
	return available
}

// RunTool executes a reconnaissance tool
func (s *Scanner) RunTool(taskType models.TaskType, target string, timeout int) *models.ScanResult {
	startTime := time.Now()
	
	result := &models.ScanResult{
		TaskType:  taskType,
		Target:    target,
		StartTime: startTime,
		Metadata:  make(map[string]string),
	}
	
	toolName := string(taskType)
	tool, exists := s.tools[toolName]
	if !exists || !tool.Available {
		result.Error = fmt.Errorf("tool %s not available", toolName)
		result.EndTime = time.Now()
		result.Duration = time.Since(startTime)
		return result
	}
	
	s.logger.WithFields(logrus.Fields{
		"tool":    toolName,
		"target":  target,
		"timeout": timeout,
	}).Info("Starting reconnaissance scan")
	
	// Create output file
	outputFile := filepath.Join(s.outputDir, fmt.Sprintf("%s_%s_%d.txt", 
		toolName, strings.ReplaceAll(target, ".", "_"), time.Now().Unix()))
	
	// Execute tool based on type
	switch taskType {
	case models.TaskSubfinder:
		result = s.runSubfinder(target, outputFile, timeout)
	case models.TaskAssetfinder:
		result = s.runAssetfinder(target, outputFile, timeout)
	case models.TaskAmass:
		result = s.runAmass(target, outputFile, timeout)
	case models.TaskFFUF:
		result = s.runFFUF(target, outputFile, timeout)
	case models.TaskSublist3r:
		result = s.runSublist3r(target, outputFile, timeout)
	case models.TaskNmap:
		result = s.runNmap(target, outputFile, timeout)
	case models.TaskWhatWeb:
		result = s.runWhatWeb(target, outputFile, timeout)
	default:
		result = s.runGenericTool(toolName, target, outputFile, timeout)
	}
	
	result.EndTime = time.Now()
	result.Duration = time.Since(startTime)
	result.TaskType = taskType
	result.Target = target
	result.OutputFile = outputFile
	
	if result.Error == nil {
		s.logger.WithFields(logrus.Fields{
			"tool":     toolName,
			"target":   target,
			"count":    result.Count,
			"duration": result.Duration,
		}).Info("Scan completed successfully")
	} else {
		s.logger.WithFields(logrus.Fields{
			"tool":   toolName,
			"target": target,
			"error":  result.Error,
		}).Error("Scan failed")
	}
	
	return result
}

// runSubfinder executes subfinder
func (s *Scanner) runSubfinder(target, outputFile string, timeout int) *models.ScanResult {
	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(timeout)*time.Second)
	defer cancel()
	
	args := []string{
		"-d", target,
		"-o", outputFile,
		"-silent",
		"-all",
	}
	
	cmd := exec.CommandContext(ctx, s.toolPaths["subfinder"], args...)
	err := cmd.Run()
	
	result := &models.ScanResult{}
	
	if err != nil {
		result.Error = fmt.Errorf("subfinder failed: %v", err)
		return result
	}
	
	subdomains, err := s.readLinesFromFile(outputFile)
	if err != nil {
		result.Error = fmt.Errorf("failed to read results: %v", err)
		return result
	}
	
	result.Subdomains = subdomains
	result.Count = len(subdomains)
	
	return result
}

// runAssetfinder executes assetfinder
func (s *Scanner) runAssetfinder(target, outputFile string, timeout int) *models.ScanResult {
	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(timeout)*time.Second)
	defer cancel()
	
	cmd := exec.CommandContext(ctx, s.toolPaths["assetfinder"], target)
	output, err := cmd.Output()
	
	result := &models.ScanResult{}
	
	if err != nil {
		result.Error = fmt.Errorf("assetfinder failed: %v", err)
		return result
	}
	
	// Save output to file
	if err := os.WriteFile(outputFile, output, 0644); err != nil {
		s.logger.WithError(err).Warn("Failed to save output to file")
	}
	
	subdomains := strings.Split(strings.TrimSpace(string(output)), "\n")
	result.Subdomains = s.cleanResults(subdomains)
	result.Count = len(result.Subdomains)
	
	return result
}

// runAmass executes amass
func (s *Scanner) runAmass(target, outputFile string, timeout int) *models.ScanResult {
	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(timeout)*time.Second)
	defer cancel()
	
	args := []string{
		"enum",
		"-d", target,
		"-o", outputFile,
		"-passive",
	}
	
	cmd := exec.CommandContext(ctx, s.toolPaths["amass"], args...)
	err := cmd.Run()
	
	result := &models.ScanResult{}
	
	if err != nil {
		result.Error = fmt.Errorf("amass failed: %v", err)
		return result
	}
	
	subdomains, err := s.readLinesFromFile(outputFile)
	if err != nil {
		result.Error = fmt.Errorf("failed to read results: %v", err)
		return result
	}
	
	result.Subdomains = subdomains
	result.Count = len(subdomains)
	
	return result
}

// runFFUF executes ffuf
func (s *Scanner) runFFUF(target, outputFile string, timeout int) *models.ScanResult {
	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(timeout)*time.Second)
	defer cancel()
	
	// Use a basic wordlist path (would need to be configured properly)
	wordlist := "/usr/share/wordlists/dirbuster/directory-list-2.3-small.txt"
	if _, err := os.Stat(wordlist); os.IsNotExist(err) {
		wordlist = "common.txt" // fallback
	}
	
	args := []string{
		"-w", wordlist,
		"-u", fmt.Sprintf("http://%s/FUZZ", target),
		"-o", outputFile,
		"-of", "csv",
		"-mc", "200,301,302,403",
		"-t", "20",
	}
	
	cmd := exec.CommandContext(ctx, s.toolPaths["ffuf"], args...)
	err := cmd.Run()
	
	result := &models.ScanResult{}
	
	if err != nil {
		result.Error = fmt.Errorf("ffuf failed: %v", err)
		return result
	}
	
	urls, err := s.readLinesFromFile(outputFile)
	if err != nil {
		result.Error = fmt.Errorf("failed to read results: %v", err)
		return result
	}
	
	result.URLs = urls
	result.Count = len(urls)
	
	return result
}

// runSublist3r executes sublist3r
func (s *Scanner) runSublist3r(target, outputFile string, timeout int) *models.ScanResult {
	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(timeout)*time.Second)
	defer cancel()
	
	args := []string{
		"-d", target,
		"-o", outputFile,
	}
	
	cmd := exec.CommandContext(ctx, "python3", append([]string{s.toolPaths["sublist3r"]}, args...)...)
	err := cmd.Run()
	
	result := &models.ScanResult{}
	
	if err != nil {
		result.Error = fmt.Errorf("sublist3r failed: %v", err)
		return result
	}
	
	subdomains, err := s.readLinesFromFile(outputFile)
	if err != nil {
		result.Error = fmt.Errorf("failed to read results: %v", err)
		return result
	}
	
	result.Subdomains = subdomains
	result.Count = len(subdomains)
	
	return result
}

// runNmap executes nmap
func (s *Scanner) runNmap(target, outputFile string, timeout int) *models.ScanResult {
	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(timeout)*time.Second)
	defer cancel()
	
	args := []string{
		"-sS",
		"-T4",
		"--top-ports", "1000",
		"-oN", outputFile,
		target,
	}
	
	// Check if running as root for SYN scan
	if os.Getuid() != 0 {
		args[0] = "-sT" // TCP connect scan for non-root
	}
	
	cmd := exec.CommandContext(ctx, s.toolPaths["nmap"], args...)
	err := cmd.Run()
	
	result := &models.ScanResult{}
	
	if err != nil {
		result.Error = fmt.Errorf("nmap failed: %v", err)
		return result
	}
	
	// Parse nmap output for open ports
	ports, err := s.parseNmapOutput(outputFile)
	if err != nil {
		result.Error = fmt.Errorf("failed to parse nmap results: %v", err)
		return result
	}
	
	result.Ports = ports
	result.Count = len(ports)
	
	return result
}

// runWhatWeb executes whatweb
func (s *Scanner) runWhatWeb(target, outputFile string, timeout int) *models.ScanResult {
	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(timeout)*time.Second)
	defer cancel()
	
	args := []string{
		target,
		"--log-brief=" + outputFile,
		"-a", "1",
	}
	
	cmd := exec.CommandContext(ctx, s.toolPaths["whatweb"], args...)
	err := cmd.Run()
	
	result := &models.ScanResult{}
	
	if err != nil {
		result.Error = fmt.Errorf("whatweb failed: %v", err)
		return result
	}
	
	services, err := s.parseWhatWebOutput(outputFile)
	if err != nil {
		result.Error = fmt.Errorf("failed to parse whatweb results: %v", err)
		return result
	}
	
	result.Services = services
	result.Count = len(services)
	
	return result
}

// runGenericTool executes a generic reconnaissance tool
func (s *Scanner) runGenericTool(toolName, target, outputFile string, timeout int) *models.ScanResult {
	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(timeout)*time.Second)
	defer cancel()
	
	args := []string{target}
	
	cmd := exec.CommandContext(ctx, s.toolPaths[toolName], args...)
	output, err := cmd.Output()
	
	result := &models.ScanResult{}
	
	if err != nil {
		result.Error = fmt.Errorf("%s failed: %v", toolName, err)
		return result
	}
	
	// Save output to file
	if err := os.WriteFile(outputFile, output, 0644); err != nil {
		s.logger.WithError(err).Warn("Failed to save output to file")
	}
	
	// Try to extract subdomains from output
	lines := strings.Split(string(output), "\n")
	result.Subdomains = s.cleanResults(lines)
	result.Count = len(result.Subdomains)
	
	return result
}

// Helper functions

// readLinesFromFile reads lines from a file
func (s *Scanner) readLinesFromFile(filename string) ([]string, error) {
	file, err := os.Open(filename)
	if err != nil {
		return nil, err
	}
	defer file.Close()
	
	var lines []string
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line != "" {
			lines = append(lines, line)
		}
	}
	
	return lines, scanner.Err()
}

// cleanResults removes empty lines and duplicates
func (s *Scanner) cleanResults(results []string) []string {
	seen := make(map[string]bool)
	var clean []string
	
	for _, result := range results {
		result = strings.TrimSpace(result)
		if result != "" && !seen[result] {
			clean = append(clean, result)
			seen[result] = true
		}
	}
	
	return clean
}

// parseNmapOutput parses nmap output for open ports
func (s *Scanner) parseNmapOutput(filename string) ([]models.PortResult, error) {
	lines, err := s.readLinesFromFile(filename)
	if err != nil {
		return nil, err
	}
	
	var ports []models.PortResult
	for _, line := range lines {
		if strings.Contains(line, "/tcp") && strings.Contains(line, "open") {
			parts := strings.Fields(line)
			if len(parts) >= 3 {
				portInfo := parts[0]
				service := parts[2]
				
				var port int
				fmt.Sscanf(portInfo, "%d/", &port)
				
				ports = append(ports, models.PortResult{
					Port:     port,
					Protocol: "tcp",
					Service:  service,
					State:    "open",
				})
			}
		}
	}
	
	return ports, nil
}

// parseWhatWebOutput parses whatweb output
func (s *Scanner) parseWhatWebOutput(filename string) ([]models.ServiceResult, error) {
	lines, err := s.readLinesFromFile(filename)
	if err != nil {
		return nil, err
	}
	
	var services []models.ServiceResult
	for _, line := range lines {
		if strings.Contains(line, "[") && strings.Contains(line, "]") {
			// Simple parsing - would need more sophisticated parsing for real use
			service := models.ServiceResult{
				Name:       "web-service",
				Confidence: 80,
			}
			services = append(services, service)
		}
	}
	
	return services, nil
}

// CleanupOldResults cleans up old result files
func (s *Scanner) CleanupOldResults(maxAge time.Duration) error {
	entries, err := os.ReadDir(s.outputDir)
	if err != nil {
		return err
	}
	
	cutoff := time.Now().Add(-maxAge)
	
	for _, entry := range entries {
		if entry.IsDir() {
			continue
		}
		
		info, err := entry.Info()
		if err != nil {
			continue
		}
		
		if info.ModTime().Before(cutoff) {
			filePath := filepath.Join(s.outputDir, entry.Name())
			if err := os.Remove(filePath); err != nil {
				s.logger.WithError(err).WithField("file", filePath).Warn("Failed to remove old file")
			} else {
				s.logger.WithField("file", entry.Name()).Debug("Removed old result file")
			}
		}
	}
	
	return nil
}

// GetSystemInfo returns system information
func (s *Scanner) GetSystemInfo() map[string]string {
	return map[string]string{
		"os":           runtime.GOOS,
		"architecture": runtime.GOARCH,
		"go_version":   runtime.Version(),
		"num_cpu":      fmt.Sprintf("%d", runtime.NumCPU()),
		"work_dir":     s.workDir,
		"output_dir":   s.outputDir,
	}
}