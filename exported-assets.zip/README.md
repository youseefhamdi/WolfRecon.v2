# 🐺 Wolf Recon MCP v2.5

**Advanced Distributed Reconnaissance Platform**

A powerful, scalable reconnaissance framework built with Go that enables distributed scanning across multiple agents using the MCP (Message Control Protocol) for real-time coordination.

---

## 🚀 **Quick Start**

```bash
# 1. Clone and setup
git clone https://github.com/wolf-cyber/wolf-recon-mcp.git
cd wolf-recon-mcp

# 2. Build the project
make build

# 3. Install reconnaissance tools
make install

# 4. Start controller (Terminal 1)
./run.sh controller

# 5. Start agent (Terminal 2) 
./run.sh agent

# 6. Begin scanning
wolf-recon> scan example.com hackerone.com
```

---

## 📋 **Features**

### 🎮 **Controller Features**
- **Interactive CLI** with 15+ commands
- **Real-time Monitoring** of agents and tasks
- **Multi-format Export** (JSON, CSV, TXT)
- **Task Load Balancing** across agents
- **Agent Health Monitoring**
- **WebSocket-based Communication**
- **Professional Logging** with structured output

### 🤖 **Agent Features**
- **12+ Reconnaissance Tools** integrated:
  - Subfinder, AssetFinder, Amass, FFUF
  - Sublist3r, Subdog, Sudomy, DNScan
  - Nmap, WhatWeb, Knockpy, BBOT
- **Auto-reconnection** with exponential backoff
- **Resource Management** with configurable limits
- **Health Monitoring** and cleanup routines
- **Cross-platform Support** (Linux, macOS, Windows)

### 🌐 **MCP Protocol Features**
- **WebSocket Communication** with message validation
- **Message Types**: Heartbeat, Task Assignment, Progress, Results
- **Connection Management** with keepalives
- **Statistics Collection** and performance tracking
- **Error Handling** with recovery suggestions

---

## 🏗️ **Architecture**

```
┌─────────────────┐    WebSocket     ┌─────────────────┐
│   Controller    │ ◄─────────────► │     Agent 1     │
│                 │    MCP Protocol  │                 │
│  • Task Queue   │                  │  • Tool Scanner │
│  • Load Balance │                  │  • Health Mon.  │
│  • Monitoring   │                  │  • Auto-recon   │
└─────────────────┘                  └─────────────────┘
         │                                     │
         │                                     │
    ┌────▼────┐                         ┌─────▼─────┐
    │ Results │                         │   Tools   │
    │ Export  │                         │ Discovery │ 
    │ Storage │                         │  Engine   │
    └─────────┘                         └───────────┘
```

---

## 📁 **Project Structure**

```
wolf-recon-mcp/
├── 📄 README.md                     # This file
├── 📄 go.mod                        # Go dependencies
├── 📄 Makefile                      # Build system (20+ targets)
├── 📄 run.sh                        # Smart execution script
├── 📄 install-tools.sh              # Tool installer
│
├── 📂 cmd/                          # Application entry points
│   ├── 📂 controller/main.go        # Controller with interactive CLI
│   └── 📂 agent/main.go             # Agent with health monitoring
│
├── 📂 internal/                     # Core application code
│   ├── 📂 mcp/                      # MCP Protocol implementation
│   │   ├── 📄 protocol.go           # Message definitions
│   │   ├── 📄 server.go             # WebSocket server
│   │   └── 📄 client.go             # WebSocket client
│   ├── 📂 models/models.go          # Data models
│   └── 📂 agent/scanner.go          # Tool scanner engine
│
├── 📂 pkg/utils/                    # Utility functions
│   └── 📄 banner.go                 # ASCII banners & UI
│
├── 📂 configs/                      # Configuration files
│   ├── 📄 controller.yaml           # Controller settings
│   └── 📄 agent.yaml               # Agent settings
│
└── 📂 bin/                          # Compiled binaries
    ├── 🔧 wolf-controller           # Controller executable  
    └── 🔧 wolf-agent               # Agent executable
```

---

## 🛠️ **Installation**

### **Prerequisites**
- **Go 1.21+** - [Download](https://golang.org/dl/)
- **Git** - For tool installation
- **Linux/macOS/Windows** - WSL2 supported

### **Method 1: Automated Setup**
```bash
# One-command setup (coming soon)
curl -sSL https://raw.githubusercontent.com/wolf-cyber/wolf-recon-mcp/main/setup.sh | bash
```

### **Method 2: Manual Installation**
```bash
# 1. Download source
git clone https://github.com/wolf-cyber/wolf-recon-mcp.git
cd wolf-recon-mcp

# 2. Build binaries
make build

# 3. Install reconnaissance tools
chmod +x install-tools.sh
./install-tools.sh

# 4. Setup configurations (optional)
make setup
```

---

## 🎯 **Usage Examples**

### **Basic Scanning**
```bash
# Start controller
./run.sh controller

# In controller CLI
wolf-recon> scan example.com
wolf-recon> status
wolf-recon> results
```

### **Multi-Target Scanning**
```bash
wolf-recon> scan hackerone.com bugcrowd.com intigriti.com
wolf-recon> monitor  # Real-time monitoring
```

### **Distributed Setup**
```bash
# Controller (Server 1)
./run.sh controller --addr 0.0.0.0:8080

# Agent (Server 2)
./run.sh agent --server 10.0.0.100:8080 --name recon-agent-1

# Agent (Server 3) 
./run.sh agent --server 10.0.0.100:8080 --name recon-agent-2 --max-tasks 10
```

### **Export Results**
```bash
wolf-recon> export json results.json
wolf-recon> export csv results.csv  
wolf-recon> export txt report.txt
```

---

## 🔧 **Configuration**

### **Controller Settings** (`configs/controller.yaml`)
```yaml
server:
  address: "0.0.0.0:8080"      # Listen address
  max_agents: 100              # Max connected agents
  task_timeout: 300            # Task timeout (seconds)

logging:
  level: "info"                # debug, info, warn, error
  format: "text"               # text, json

api:
  enabled: true                # Enable REST API
  rate_limit: 1000             # Requests per minute
```

### **Agent Settings** (`configs/agent.yaml`)
```yaml
server:
  address: "localhost:8080"    # Controller address
  reconnect_interval: 5        # Reconnect delay

agent:
  name: "wolf-agent"           # Agent identifier  
  max_tasks: 5                 # Concurrent task limit
  work_directory: "./agent-work" # Working directory

tools:
  enabled: ["subfinder", "amass", "ffuf"]  # Enabled tools
  timeout: 300                 # Tool timeout
```

---

## 🎮 **CLI Commands Reference**

### **Scanning Commands**
```bash
scan <targets>           # Multi-target reconnaissance
scan-file targets.txt    # Scan from file
quick-scan <targets>     # Fast basic scan
deep-scan <targets>      # Comprehensive scan
```

### **Monitoring Commands**
```bash
status                   # Controller status
agents                   # List connected agents
tasks                    # Show task status
monitor                  # Real-time monitoring
results                  # Display results
```

### **Management Commands**
```bash
export <format> [file]   # Export results (json/csv/txt)
config list              # Show configuration
clear                    # Clear screen
help                     # Show help
quit                     # Exit controller
```

---

## 🔍 **Supported Tools**

| Tool | Type | Purpose | Status |
|------|------|---------|--------|
| **Subfinder** | Passive | Subdomain discovery | ✅ Active |
| **AssetFinder** | Passive | Asset enumeration | ✅ Active |
| **Amass** | Active/Passive | OSINT reconnaissance | ✅ Active |
| **FFUF** | Active | Web directory fuzzing | ✅ Active |
| **Sublist3r** | Passive | Search engine enum | ✅ Active |
| **Nmap** | Active | Port scanning | ✅ Active |
| **WhatWeb** | Active | Technology detection | ✅ Active |
| **BBOT** | Comprehensive | Full recon suite | ✅ Active |
| **Subdog** | Passive | Subdomain discovery | ✅ Active |
| **Knockpy** | Active | Subdomain enumeration | ✅ Active |

---

## 📊 **Performance & Scaling**

### **Resource Requirements**
- **Small VPS (2GB RAM)**: 2-3 concurrent tasks, 10+ targets/hour
- **Medium Server (8GB RAM)**: 5-10 concurrent tasks, 50+ targets/hour  
- **Large Server (16GB+ RAM)**: 10+ concurrent tasks, 100+ targets/hour

### **Scaling Guidelines**
```bash
# Single target: 1 agent sufficient
# 10 targets: 2-3 agents recommended
# 100+ targets: 5-10 agents optimal
# Enterprise: 10+ agents across multiple servers
```

### **Network Considerations**
- Use VPN for anonymity if required
- Rate limit requests to avoid detection
- Respect robots.txt and terms of service

---

## 🛡️ **Security & Legal**

### **Authorized Testing Only**
⚠️ **This tool is for authorized security testing only**

- Only scan systems you own or have explicit permission to test
- Follow responsible disclosure for vulnerability findings  
- Comply with bug bounty program rules and scope
- Respect rate limits and avoid aggressive scanning

### **Legal Compliance**
- Ensure compliance with local computer crime laws
- Obtain proper authorization before testing
- Document permission and scope clearly
- Use responsibly for legitimate security research

---

## 🐛 **Troubleshooting**

### **Common Issues**

**Agent Not Connecting**
```bash
# Check controller address
./run.sh agent --server CORRECT_IP:8080

# Check firewall  
sudo ufw allow 8080
```

**Tools Not Found**
```bash
# Reinstall tools
make install

# Check PATH
export PATH=$PATH:$HOME/go/bin:$HOME/.local/bin

# Verify manually
which subfinder assetfinder amass
```

**Build Errors**
```bash
# Clean and rebuild
make clean
go mod tidy
make build
```

**Permission Errors**
```bash
# Make scripts executable
chmod +x run.sh install-tools.sh
```

---

## 🚀 **Development**

### **Building from Source**
```bash
# Standard build
make build

# Development build with debugging
make build-dev

# Cross-platform builds
make build-all-platforms

# Run tests
make test

# Code linting
make lint
```

### **Contributing**
1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

---

## 📞 **Support & Community**

- **🐛 Issues**: [GitHub Issues](https://github.com/wolf-cyber/wolf-recon-mcp/issues)
- **📖 Documentation**: [Wiki](https://github.com/wolf-cyber/wolf-recon-mcp/wiki)
- **💬 Discussions**: [GitHub Discussions](https://github.com/wolf-cyber/wolf-recon-mcp/discussions)
- **🔔 Updates**: Watch repository for releases

---

## 📝 **Changelog**

### **v2.5 - Current Release**
- ✅ Complete MCP protocol implementation  
- ✅ 12+ integrated reconnaissance tools
- ✅ Interactive CLI with real-time monitoring
- ✅ Multi-format result export
- ✅ Auto-reconnection and error recovery
- ✅ Professional logging and statistics
- ✅ Cross-platform support

### **Roadmap**
- 🔲 Web dashboard interface
- 🔲 Docker containers and Kubernetes deployment
- 🔲 Database persistence for results
- 🔲 Advanced scheduling and prioritization
- 🔲 Plugin system for custom tools
- 🔲 API endpoints for external integration

---

## 📄 **License**

This project is licensed under the **MIT License** - see the [LICENSE](LICENSE) file for details.

**Additional Terms:**
- This software is for legitimate security research only
- Users must comply with applicable laws and regulations
- Authors assume no liability for misuse

---

## 🎉 **Acknowledgments**

- **ProjectDiscovery** - For excellent reconnaissance tools
- **OWASP Amass** - For comprehensive OSINT capabilities  
- **Go Community** - For robust WebSocket libraries
- **Security Research Community** - For inspiration and feedback

---

<div align="center">

**🐺 Wolf Recon MCP - Advanced Distributed Reconnaissance Platform**

Made with ❤️ for the security research community

⭐ **Star this repository if you find it useful!** ⭐

</div>