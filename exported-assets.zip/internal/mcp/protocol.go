package mcp

import (
	"encoding/json"
	"fmt"
	"time"
	
	"github.com/google/uuid"
)

// MessageType represents the type of MCP message
type MessageType string

// MCP Message Types
const (
	MessageHeartbeat       MessageType = "heartbeat"
	MessageStatusUpdate    MessageType = "status_update"
	MessageTaskAssignment  MessageType = "task_assignment"
	MessageTaskResult      MessageType = "task_result"
	MessageTaskProgress    MessageType = "task_progress"
	MessageTaskCancel      MessageType = "task_cancel"
	MessageError           MessageType = "error"
	MessagePing            MessageType = "ping"
	MessagePong            MessageType = "pong"
	MessageAck             MessageType = "ack"
	MessageKeepAlive       MessageType = "keep_alive"
	MessageShutdown        MessageType = "shutdown"
	MessageAgentConfig     MessageType = "agent_config"
	MessageHealthCheck     MessageType = "health_check"
	MessageHealthStatus    MessageType = "health_status"
)

// Message represents a complete MCP message
type Message struct {
	ID         string                 `json:"id"`
	Type       MessageType            `json:"type"`
	From       string                 `json:"from"`
	To         string                 `json:"to,omitempty"`
	Timestamp  int64                  `json:"timestamp"`
	Payload    map[string]interface{} `json:"payload,omitempty"`
	ResponseTo string                 `json:"response_to,omitempty"`
	Priority   int                    `json:"priority,omitempty"`
	TTL        int                    `json:"ttl,omitempty"`
	Compressed bool                   `json:"compressed,omitempty"`
}

// TaskAssignment represents a task assignment payload
type TaskAssignment struct {
	TaskID     string                 `json:"task_id"`
	Type       string                 `json:"type"`
	Target     string                 `json:"target"`
	Priority   int                    `json:"priority"`
	Timeout    int                    `json:"timeout"`
	MaxRetries int                    `json:"max_retries"`
	Options    map[string]interface{} `json:"options,omitempty"`
	Tags       []string               `json:"tags,omitempty"`
}

// TaskResultPayload represents task execution results
type TaskResultPayload struct {
	TaskID       string            `json:"task_id"`
	Status       string            `json:"status"`
	Error        string            `json:"error,omitempty"`
	Subdomains   []string          `json:"subdomains,omitempty"`
	IPs          []string          `json:"ips,omitempty"`
	URLs         []string          `json:"urls,omitempty"`
	Count        int               `json:"count"`
	Duration     int64             `json:"duration"`
	StartTime    int64             `json:"start_time"`
	EndTime      int64             `json:"end_time"`
	OutputFile   string            `json:"output_file,omitempty"`
	Screenshots  []string          `json:"screenshots,omitempty"`
	Metadata     map[string]string `json:"metadata,omitempty"`
	Statistics   *TaskStatistics   `json:"statistics,omitempty"`
}

// TaskProgressPayload represents task progress updates
type TaskProgressPayload struct {
	TaskID    string  `json:"task_id"`
	Progress  float64 `json:"progress"`
	Stage     string  `json:"stage"`
	Message   string  `json:"message"`
	Timestamp int64   `json:"timestamp"`
}

// AgentStatusPayload represents agent status information
type AgentStatusPayload struct {
	AgentID        string        `json:"agent_id"`
	Name           string        `json:"name"`
	Status         string        `json:"status"`
	Version        string        `json:"version"`
	Capabilities   []string      `json:"capabilities"`
	MaxTasks       int           `json:"max_tasks"`
	CurrentTasks   int           `json:"current_tasks"`
	CompletedTasks int           `json:"completed_tasks"`
	FailedTasks    int           `json:"failed_tasks"`
	Uptime         int64         `json:"uptime"`
	Resources      *ResourceInfo `json:"resources,omitempty"`
	LastActivity   int64         `json:"last_activity"`
	Platform       string        `json:"platform"`
	Architecture   string        `json:"architecture"`
	Tags           []string      `json:"tags,omitempty"`
}

// ResourceInfo represents system resource information
type ResourceInfo struct {
	CPUUsage    float64 `json:"cpu_usage"`
	MemoryUsage float64 `json:"memory_usage"`
	DiskUsage   float64 `json:"disk_usage"`
	Goroutines  int     `json:"goroutines"`
}

// TaskStatistics represents task execution statistics
type TaskStatistics struct {
	TotalRequests   int   `json:"total_requests"`
	SuccessfulReqs  int   `json:"successful_requests"`
	FailedRequests  int   `json:"failed_requests"`
	DataTransferred int64 `json:"data_transferred"`
	UniqueResults   int   `json:"unique_results"`
	DuplicatesFound int   `json:"duplicates_found"`
}

// ErrorPayload represents error information
type ErrorPayload struct {
	Code        string            `json:"code"`
	Message     string            `json:"message"`
	TaskID      string            `json:"task_id,omitempty"`
	Timestamp   int64             `json:"timestamp"`
	Details     map[string]string `json:"details,omitempty"`
	Recoverable bool              `json:"recoverable"`
	Suggestions []string          `json:"suggestions,omitempty"`
}

// ConfigPayload represents configuration updates
type ConfigPayload struct {
	Version    string                 `json:"version"`
	Settings   map[string]interface{} `json:"settings"`
	UpdateTime int64                  `json:"update_time"`
}

// HealthCheckPayload represents health check information
type HealthCheckPayload struct {
	AgentID   string                 `json:"agent_id"`
	Healthy   bool                   `json:"healthy"`
	Checks    map[string]HealthCheck `json:"checks"`
	Timestamp int64                  `json:"timestamp"`
	Version   string                 `json:"version"`
}

// HealthCheck represents individual health check result
type HealthCheck struct {
	Status    string                 `json:"status"`
	Message   string                 `json:"message"`
	Duration  int64                  `json:"duration"`
	Timestamp int64                  `json:"timestamp"`
	Metadata  map[string]interface{} `json:"metadata,omitempty"`
}

// NewMessage creates a new MCP message
func NewMessage(msgType MessageType, from string) *Message {
	return &Message{
		ID:        uuid.New().String(),
		Type:      msgType,
		From:      from,
		Timestamp: time.Now().Unix(),
		Payload:   make(map[string]interface{}),
	}
}

// SetPayload sets a payload value
func (m *Message) SetPayload(key string, value interface{}) {
	if m.Payload == nil {
		m.Payload = make(map[string]interface{})
	}
	m.Payload[key] = value
}

// GetPayload gets a payload value
func (m *Message) GetPayload(key string) (interface{}, bool) {
	if m.Payload == nil {
		return nil, false
	}
	value, exists := m.Payload[key]
	return value, exists
}

// GetPayloadString gets a string payload value
func (m *Message) GetPayloadString(key string) (string, bool) {
	value, exists := m.GetPayload(key)
	if !exists {
		return "", false
	}
	
	if str, ok := value.(string); ok {
		return str, true
	}
	return "", false
}

// SetRequestID sets the request ID for response tracking
func (m *Message) SetRequestID(requestID string) {
	m.SetPayload("request_id", requestID)
}

// ToJSON serializes the message to JSON
func (m *Message) ToJSON() ([]byte, error) {
	return json.Marshal(m)
}

// FromJSON deserializes JSON to message
func FromJSON(data []byte) (*Message, error) {
	var msg Message
	err := json.Unmarshal(data, &msg)
	return &msg, err
}

// Validate validates the message structure
func (m *Message) Validate() error {
	if m.ID == "" {
		return fmt.Errorf("message ID is required")
	}
	
	if m.Type == "" {
		return fmt.Errorf("message type is required")
	}
	
	if m.From == "" {
		return fmt.Errorf("message sender is required")
	}
	
	if m.Timestamp <= 0 {
		return fmt.Errorf("message timestamp is required")
	}
	
	return nil
}