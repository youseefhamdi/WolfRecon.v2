package models

import (
	"time"
	"fmt"
)

// TaskType represents the type of reconnaissance task
type TaskType string

// Available task types
const (
	TaskSubfinder    TaskType = "subfinder"
	TaskAssetfinder  TaskType = "assetfinder"
	TaskAmass        TaskType = "amass"
	TaskFFUF         TaskType = "ffuf"
	TaskSublist3r    TaskType = "sublist3r"
	TaskSubdog       TaskType = "subdog"
	TaskSudomy       TaskType = "sudomy"
	TaskDNScan       TaskType = "dnscan"
	TaskNmap         TaskType = "nmap"
	TaskWhatWeb      TaskType = "whatweb"
	TaskKnockpy      TaskType = "knockpy"
	TaskBBOT         TaskType = "bbot"
)

// TaskStatus represents the status of a task
type TaskStatus string

// Task status values
const (
	TaskPending   TaskStatus = "pending"
	TaskRunning   TaskStatus = "running"
	TaskCompleted TaskStatus = "completed"
	TaskFailed    TaskStatus = "failed"
	TaskCanceled  TaskStatus = "canceled"
)

// TaskPriority represents task priority level
type TaskPriority int

// Priority levels
const (
	PriorityLow       TaskPriority = 1
	PriorityNormal    TaskPriority = 2
	PriorityHigh      TaskPriority = 3
	PriorityUrgent    TaskPriority = 4
	PriorityEmergency TaskPriority = 5
)

// AgentStatus represents agent connection status
type AgentStatus string

// Agent status values
const (
	AgentOffline AgentStatus = "offline"
	AgentOnline  AgentStatus = "online"
	AgentBusy    AgentStatus = "busy"
	AgentError   AgentStatus = "error"
)

// Task represents a reconnaissance task
type Task struct {
	ID          string                 `json:"id"`
	Type        TaskType               `json:"type"`
	Target      string                 `json:"target"`
	Status      TaskStatus             `json:"status"`
	Priority    TaskPriority           `json:"priority"`
	AgentID     string                 `json:"agent_id,omitempty"`
	CreatedAt   time.Time              `json:"created_at"`
	StartedAt   *time.Time             `json:"started_at,omitempty"`
	CompletedAt *time.Time             `json:"completed_at,omitempty"`
	Progress    float64                `json:"progress"`
	Result      *TaskResult            `json:"result,omitempty"`
	Error       string                 `json:"error,omitempty"`
	Timeout     int                    `json:"timeout"`
	MaxRetries  int                    `json:"max_retries"`
	Retries     int                    `json:"retries"`
	Options     map[string]interface{} `json:"options,omitempty"`
	Tags        []string               `json:"tags,omitempty"`
	Metadata    map[string]string      `json:"metadata,omitempty"`
}

// TaskResult represents the result of a task execution
type TaskResult struct {
	Subdomains   []string           `json:"subdomains,omitempty"`
	IPs          []string           `json:"ips,omitempty"`
	URLs         []string           `json:"urls,omitempty"`
	Ports        []PortResult       `json:"ports,omitempty"`
	Services     []ServiceResult    `json:"services,omitempty"`
	Count        int                `json:"count"`
	Duration     time.Duration      `json:"duration"`
	OutputFile   string             `json:"output_file,omitempty"`
	Screenshots  []string           `json:"screenshots,omitempty"`
	Metadata     map[string]string  `json:"metadata,omitempty"`
	Statistics   *TaskStatistics    `json:"statistics,omitempty"`
}

// PortResult represents an open port discovery
type PortResult struct {
	Port     int    `json:"port"`
	Protocol string `json:"protocol"`
	Service  string `json:"service,omitempty"`
	Version  string `json:"version,omitempty"`
	State    string `json:"state"`
}

// ServiceResult represents a discovered service
type ServiceResult struct {
	Name        string            `json:"name"`
	Version     string            `json:"version,omitempty"`
	Port        int               `json:"port,omitempty"`
	Protocol    string            `json:"protocol,omitempty"`
	Confidence  int               `json:"confidence"`
	Fingerprint map[string]string `json:"fingerprint,omitempty"`
}

// TaskStatistics represents task execution statistics
type TaskStatistics struct {
	TotalRequests   int   `json:"total_requests"`
	SuccessfulReqs  int   `json:"successful_requests"`
	FailedRequests  int   `json:"failed_requests"`
	DataTransferred int64 `json:"data_transferred"`
	UniqueResults   int   `json:"unique_results"`
	DuplicatesFound int   `json:"duplicates_found"`
	ErrorRate       float64 `json:"error_rate"`
}

// AgentInfo represents information about an agent
type AgentInfo struct {
	ID             string            `json:"id"`
	Name           string            `json:"name"`
	Status         AgentStatus       `json:"status"`
	Version        string            `json:"version"`
	Capabilities   []string          `json:"capabilities"`
	MaxTasks       int               `json:"max_tasks"`
	CurrentTasks   int               `json:"current_tasks"`
	CompletedTasks int               `json:"completed_tasks"`
	FailedTasks    int               `json:"failed_tasks"`
	LastSeen       time.Time         `json:"last_seen"`
	ConnectedAt    time.Time         `json:"connected_at"`
	Platform       string            `json:"platform"`
	Architecture   string            `json:"architecture"`
	Resources      *ResourceUsage    `json:"resources,omitempty"`
	Tags           []string          `json:"tags,omitempty"`
	Config         map[string]string `json:"config,omitempty"`
}

// ResourceUsage represents agent resource usage
type ResourceUsage struct {
	CPUPercent    float64 `json:"cpu_percent"`
	MemoryPercent float64 `json:"memory_percent"`
	DiskPercent   float64 `json:"disk_percent"`
	NetworkRx     int64   `json:"network_rx"`
	NetworkTx     int64   `json:"network_tx"`
	Goroutines    int     `json:"goroutines"`
	OpenFiles     int     `json:"open_files"`
}

// ScanResult represents the result of a reconnaissance scan
type ScanResult struct {
	TaskID       string            `json:"task_id"`
	TaskType     TaskType          `json:"task_type"`
	Target       string            `json:"target"`
	Subdomains   []string          `json:"subdomains,omitempty"`
	IPs          []string          `json:"ips,omitempty"`
	URLs         []string          `json:"urls,omitempty"`
	Ports        []PortResult      `json:"ports,omitempty"`
	Services     []ServiceResult   `json:"services,omitempty"`
	Count        int               `json:"count"`
	Duration     time.Duration     `json:"duration"`
	StartTime    time.Time         `json:"start_time"`
	EndTime      time.Time         `json:"end_time"`
	OutputFile   string            `json:"output_file,omitempty"`
	Screenshots  []string          `json:"screenshots,omitempty"`
	Error        error             `json:"error,omitempty"`
	Metadata     map[string]string `json:"metadata,omitempty"`
	Statistics   *TaskStatistics   `json:"statistics,omitempty"`
}

// NewTask creates a new task with default values
func NewTask(taskType TaskType, target string, timeout int) *Task {
	return &Task{
		ID:         fmt.Sprintf("task-%d", time.Now().UnixNano()),
		Type:       taskType,
		Target:     target,
		Status:     TaskPending,
		Priority:   PriorityNormal,
		CreatedAt:  time.Now(),
		Progress:   0.0,
		Timeout:    timeout,
		MaxRetries: 3,
		Retries:    0,
		Options:    make(map[string]interface{}),
		Metadata:   make(map[string]string),
	}
}

// GetDuration returns the task execution duration
func (t *Task) GetDuration() time.Duration {
	if t.StartedAt == nil {
		return 0
	}
	
	end := time.Now()
	if t.CompletedAt != nil {
		end = *t.CompletedAt
	}
	
	return end.Sub(*t.StartedAt)
}

// IsExpired checks if the task has exceeded its timeout
func (t *Task) IsExpired() bool {
	if t.StartedAt == nil || t.Timeout <= 0 {
		return false
	}
	
	return time.Since(*t.StartedAt) > time.Duration(t.Timeout)*time.Second
}

// CanRetry checks if the task can be retried
func (t *Task) CanRetry() bool {
	return t.Retries < t.MaxRetries
}

// IsAvailable checks if agent is available for new tasks
func (a *AgentInfo) IsAvailable() bool {
	return a.Status == AgentOnline && a.CurrentTasks < a.MaxTasks
}

// SupportsTask checks if agent supports the given task type
func (a *AgentInfo) SupportsTask(taskType TaskType) bool {
	taskTypeStr := string(taskType)
	for _, capability := range a.Capabilities {
		if capability == taskTypeStr {
			return true
		}
	}
	return false
}

// GetAgentLoad returns the current load percentage
func (a *AgentInfo) GetAgentLoad() float64 {
	if a.MaxTasks == 0 {
		return 0.0
	}
	return float64(a.CurrentTasks) / float64(a.MaxTasks) * 100.0
}

// GetSuccessRate returns the task success rate
func (a *AgentInfo) GetSuccessRate() float64 {
	total := a.CompletedTasks + a.FailedTasks
	if total == 0 {
		return 1.0 // New agent, assume 100% success rate
	}
	return float64(a.CompletedTasks) / float64(total)
}

// GetAge returns how long the agent has been connected
func (a *AgentInfo) GetAge() time.Duration {
	return time.Since(a.ConnectedAt)
}

// GetLastSeenDuration returns how long since last seen
func (a *AgentInfo) GetLastSeenDuration() time.Duration {
	return time.Since(a.LastSeen)
}

// IsHealthy checks if agent is healthy based on last seen time
func (a *AgentInfo) IsHealthy() bool {
	return time.Since(a.LastSeen) < 2*time.Minute
}

// String returns string representation of task
func (t *Task) String() string {
	return fmt.Sprintf("Task{ID: %s, Type: %s, Target: %s, Status: %s}", 
		t.ID, t.Type, t.Target, t.Status)
}

// String returns string representation of agent
func (a *AgentInfo) String() string {
	return fmt.Sprintf("Agent{ID: %s, Name: %s, Status: %s, Tasks: %d/%d}", 
		a.ID, a.Name, a.Status, a.CurrentTasks, a.MaxTasks)
}