package mcp

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"sync"
	"time"
	
	"github.com/gorilla/websocket"
	"github.com/sirupsen/logrus"
)

// Server represents the MCP WebSocket server
type Server struct {
	addr        string
	upgrader    websocket.Upgrader
	clients     map[string]*Client
	clientsMux  sync.RWMutex
	handlers    map[MessageType]MessageHandler
	logger      *logrus.Logger
	ctx         context.Context
	cancel      context.CancelFunc
	server      *http.Server
	stats       *ServerStats
	statsMux    sync.RWMutex
}

// Client represents a connected WebSocket client
type Client struct {
	ID       string
	Name     string
	Conn     *websocket.Conn
	Send     chan *Message
	Server   *Server
	LastSeen time.Time
	ctx      context.Context
	cancel   context.CancelFunc
	metadata map[string]interface{}
}

// ServerStats holds server statistics
type ServerStats struct {
	StartTime        time.Time `json:"start_time"`
	TotalConnections int       `json:"total_connections"`
	ActiveClients    int       `json:"active_clients"`
	MessagesHandled  int       `json:"messages_handled"`
	BytesTransferred int64     `json:"bytes_transferred"`
	Errors           int       `json:"errors"`
}

// MessageHandler is a function that handles MCP messages
type MessageHandler func(*Client, *Message) error

// NewServer creates a new MCP server
func NewServer(addr string, logger *logrus.Logger) *Server {
	ctx, cancel := context.WithCancel(context.Background())
	
	return &Server{
		addr: addr,
		upgrader: websocket.Upgrader{
			CheckOrigin: func(r *http.Request) bool {
				return true
			},
			ReadBufferSize:  1024,
			WriteBufferSize: 1024,
		},
		clients:  make(map[string]*Client),
		handlers: make(map[MessageType]MessageHandler),
		logger:   logger,
		ctx:      ctx,
		cancel:   cancel,
		stats: &ServerStats{
			StartTime: time.Now(),
		},
	}
}

// RegisterHandler registers a message handler
func (s *Server) RegisterHandler(msgType MessageType, handler MessageHandler) {
	s.handlers[msgType] = handler
}

// Start starts the WebSocket server
func (s *Server) Start() error {
	mux := http.NewServeMux()
	mux.HandleFunc("/ws", s.handleWebSocket)
	mux.HandleFunc("/health", s.handleHealth)
	mux.HandleFunc("/stats", s.handleStats)
	
	s.server = &http.Server{
		Addr:         s.addr,
		Handler:      mux,
		ReadTimeout:  60 * time.Second,
		WriteTimeout: 60 * time.Second,
		IdleTimeout:  120 * time.Second,
	}
	
	s.logger.Infof("Starting MCP server on %s", s.addr)
	
	go func() {
		<-s.ctx.Done()
		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		s.server.Shutdown(ctx)
	}()
	
	go s.cleanupRoutine()
	
	return s.server.ListenAndServe()
}

// Stop stops the server gracefully
func (s *Server) Stop() {
	s.logger.Info("Stopping MCP server...")
	
	s.clientsMux.Lock()
	for _, client := range s.clients {
		client.cancel()
		close(client.Send)
		client.Conn.Close()
	}
	s.clientsMux.Unlock()
	
	s.cancel()
}

// handleWebSocket handles WebSocket connection upgrades
func (s *Server) handleWebSocket(w http.ResponseWriter, r *http.Request) {
	conn, err := s.upgrader.Upgrade(w, r, nil)
	if err != nil {
		s.logger.WithError(err).Error("Failed to upgrade WebSocket connection")
		s.statsMux.Lock()
		s.stats.Errors++
		s.statsMux.Unlock()
		return
	}
	
	clientCtx, clientCancel := context.WithCancel(s.ctx)
	clientID := fmt.Sprintf("client-%d", time.Now().UnixNano())
	
	client := &Client{
		ID:       clientID,
		Conn:     conn,
		Send:     make(chan *Message, 256),
		Server:   s,
		LastSeen: time.Now(),
		ctx:      clientCtx,
		cancel:   clientCancel,
		metadata: make(map[string]interface{}),
	}
	
	s.clientsMux.Lock()
	s.clients[clientID] = client
	s.stats.TotalConnections++
	s.stats.ActiveClients++
	s.clientsMux.Unlock()
	
	s.logger.WithField("client_id", clientID).Info("New client connected")
	
	go client.writePump()
	go client.readPump()
}

// handleHealth provides health check endpoint
func (s *Server) handleHealth(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	
	health := map[string]interface{}{
		"status":         "healthy",
		"timestamp":      time.Now().Unix(),
		"active_clients": s.getActiveClientCount(),
		"uptime":         time.Since(s.stats.StartTime).String(),
	}
	
	json.NewEncoder(w).Encode(health)
}

// handleStats provides server statistics
func (s *Server) handleStats(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	
	s.statsMux.RLock()
	stats := *s.stats
	s.statsMux.RUnlock()
	
	stats.ActiveClients = s.getActiveClientCount()
	
	json.NewEncoder(w).Encode(stats)
}

// SendToClient sends a message to a specific client
func (s *Server) SendToClient(clientID string, msg *Message) error {
	s.clientsMux.RLock()
	client, exists := s.clients[clientID]
	s.clientsMux.RUnlock()
	
	if !exists {
		return fmt.Errorf("client %s not found", clientID)
	}
	
	msg.To = clientID
	
	select {
	case client.Send <- msg:
		return nil
	case <-time.After(5 * time.Second):
		return fmt.Errorf("timeout sending message to client %s", clientID)
	default:
		return fmt.Errorf("client %s message queue full", clientID)
	}
}

// GetClients returns all connected clients
func (s *Server) GetClients() []*Client {
	s.clientsMux.RLock()
	defer s.clientsMux.RUnlock()
	
	clients := make([]*Client, 0, len(s.clients))
	for _, client := range s.clients {
		clients = append(clients, client)
	}
	return clients
}

func (s *Server) getActiveClientCount() int {
	s.clientsMux.RLock()
	defer s.clientsMux.RUnlock()
	return len(s.clients)
}

// cleanupRoutine periodically cleans up disconnected clients
func (s *Server) cleanupRoutine() {
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()
	
	for {
		select {
		case <-s.ctx.Done():
			return
		case <-ticker.C:
			s.cleanupDisconnectedClients()
		}
	}
}

func (s *Server) cleanupDisconnectedClients() {
	s.clientsMux.Lock()
	defer s.clientsMux.Unlock()
	
	cutoff := time.Now().Add(-2 * time.Minute)
	var toDelete []string
	
	for id, client := range s.clients {
		if client.LastSeen.Before(cutoff) {
			toDelete = append(toDelete, id)
			s.logger.WithField("client_id", id).Warn("Removing inactive client")
		}
	}
	
	for _, id := range toDelete {
		if client, exists := s.clients[id]; exists {
			client.cancel()
			close(client.Send)
			client.Conn.Close()
			delete(s.clients, id)
			s.stats.ActiveClients--
		}
	}
}

// Client methods

// readPump handles reading messages from WebSocket
func (c *Client) readPump() {
	defer func() {
		c.Server.clientsMux.Lock()
		delete(c.Server.clients, c.ID)
		c.Server.stats.ActiveClients--
		c.Server.clientsMux.Unlock()
		c.Conn.Close()
	}()
	
	c.Conn.SetReadLimit(512 * 1024)
	c.Conn.SetReadDeadline(time.Now().Add(60 * time.Second))
	c.Conn.SetPongHandler(func(string) error {
		c.Conn.SetReadDeadline(time.Now().Add(60 * time.Second))
		c.LastSeen = time.Now()
		return nil
	})
	
	for {
		select {
		case <-c.ctx.Done():
			return
		default:
			_, data, err := c.Conn.ReadMessage()
			if err != nil {
				if websocket.IsUnexpectedCloseError(err, websocket.CloseGoingAway, websocket.CloseAbnormalClosure) {
					c.Server.logger.WithError(err).WithField("client_id", c.ID).Error("WebSocket error")
				}
				return
			}
			
			c.Server.statsMux.Lock()
			c.Server.stats.BytesTransferred += int64(len(data))
			c.Server.statsMux.Unlock()
			
			var msg Message
			if err := json.Unmarshal(data, &msg); err != nil {
				c.Server.logger.WithError(err).WithField("client_id", c.ID).Error("Failed to unmarshal message")
				continue
			}
			
			if err := msg.Validate(); err != nil {
				c.Server.logger.WithError(err).WithField("client_id", c.ID).Error("Invalid message")
				continue
			}
			
			c.LastSeen = time.Now()
			if c.Name == "" && msg.From != "" {
				c.Name = msg.From
			}
			
			if handler, exists := c.Server.handlers[msg.Type]; exists {
				if err := handler(c, &msg); err != nil {
					c.Server.logger.WithError(err).Error("Error handling message")
					c.Server.statsMux.Lock()
					c.Server.stats.Errors++
					c.Server.statsMux.Unlock()
				} else {
					c.Server.statsMux.Lock()
					c.Server.stats.MessagesHandled++
					c.Server.statsMux.Unlock()
				}
			}
		}
	}
}

// writePump handles writing messages to WebSocket
func (c *Client) writePump() {
	ticker := time.NewTicker(54 * time.Second)
	defer func() {
		ticker.Stop()
		c.Conn.Close()
	}()
	
	for {
		select {
		case msg, ok := <-c.Send:
			c.Conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
			if !ok {
				c.Conn.WriteMessage(websocket.CloseMessage, []byte{})
				return
			}
			
			data, err := msg.ToJSON()
			if err != nil {
				c.Server.logger.WithError(err).Error("Failed to serialize message")
				continue
			}
			
			if err := c.Conn.WriteMessage(websocket.TextMessage, data); err != nil {
				c.Server.logger.WithError(err).Error("Failed to write message")
				return
			}
			
			c.Server.statsMux.Lock()
			c.Server.stats.BytesTransferred += int64(len(data))
			c.Server.statsMux.Unlock()
			
		case <-ticker.C:
			c.Conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
			if err := c.Conn.WriteMessage(websocket.PingMessage, nil); err != nil {
				return
			}
			
		case <-c.ctx.Done():
			return
		}
	}
}