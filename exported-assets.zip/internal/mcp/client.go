package mcp

import (
	"context"
	"encoding/json"
	"fmt"
	"net/url"
	"sync"
	"time"
	
	"github.com/gorilla/websocket"
	"github.com/sirupsen/logrus"
)

// MCPClient represents an MCP WebSocket client
type MCPClient struct {
	serverAddr     string
	conn           *websocket.Conn
	handlers       map[MessageType]MessageHandler
	logger         *logrus.Logger
	ctx            context.Context
	cancel         context.CancelFunc
	reconnectMux   sync.Mutex
	clientID       string
	clientName     string
	connected      bool
	connMux        sync.RWMutex
	stats          *ClientStats
	statsMux       sync.RWMutex
	reconnectDelay time.Duration
	maxReconnects  int
	reconnectCount int
}

// ClientStats holds client statistics
type ClientStats struct {
	ConnectedAt      time.Time `json:"connected_at"`
	LastMessageTime  time.Time `json:"last_message_time"`
	MessagesSent     int       `json:"messages_sent"`
	MessagesReceived int       `json:"messages_received"`
	BytesSent        int64     `json:"bytes_sent"`
	BytesReceived    int64     `json:"bytes_received"`
	ReconnectCount   int       `json:"reconnect_count"`
	Errors           int       `json:"errors"`
}

// NewClient creates a new MCP client
func NewClient(serverAddr, clientID, clientName string, logger *logrus.Logger) *MCPClient {
	ctx, cancel := context.WithCancel(context.Background())
	
	return &MCPClient{
		serverAddr:     serverAddr,
		handlers:       make(map[MessageType]MessageHandler),
		logger:         logger,
		ctx:            ctx,
		cancel:         cancel,
		clientID:       clientID,
		clientName:     clientName,
		reconnectDelay: 5 * time.Second,
		maxReconnects:  10,
		stats: &ClientStats{
			ConnectedAt: time.Now(),
		},
	}
}

// RegisterHandler registers a message handler
func (c *MCPClient) RegisterHandler(msgType MessageType, handler MessageHandler) {
	c.handlers[msgType] = handler
}

// Connect establishes connection to MCP server
func (c *MCPClient) Connect() error {
	c.reconnectMux.Lock()
	defer c.reconnectMux.Unlock()
	
	u := url.URL{Scheme: "ws", Host: c.serverAddr, Path: "/ws"}
	c.logger.WithField("url", u.String()).Info("Connecting to MCP server")
	
	dialer := websocket.DefaultDialer
	dialer.HandshakeTimeout = 10 * time.Second
	
	conn, _, err := dialer.Dial(u.String(), nil)
	if err != nil {
		c.statsMux.Lock()
		c.stats.Errors++
		c.statsMux.Unlock()
		return fmt.Errorf("failed to connect to server: %v", err)
	}
	
	c.connMux.Lock()
	c.conn = conn
	c.connected = true
	c.connMux.Unlock()
	
	c.statsMux.Lock()
	c.stats.ConnectedAt = time.Now()
	c.statsMux.Unlock()
	
	c.logger.Info("Connected to MCP server")
	
	go c.readPump()
	go c.writePump()
	
	heartbeat := NewMessage(MessageHeartbeat, c.clientID)
	heartbeat.SetPayload("client_name", c.clientName)
	heartbeat.SetPayload("timestamp", time.Now().Unix())
	heartbeat.SetPayload("client_version", "2.5")
	
	return c.SendMessage(heartbeat)
}

// Disconnect closes connection to server
func (c *MCPClient) Disconnect() {
	c.logger.Info("Disconnecting from MCP server")
	
	c.connMux.Lock()
	if c.conn != nil {
		c.conn.WriteMessage(websocket.CloseMessage, websocket.FormatCloseMessage(websocket.CloseNormalClosure, ""))
		c.conn.Close()
		c.connected = false
	}
	c.connMux.Unlock()
	
	c.cancel()
}

// SendMessage sends a message to server
func (c *MCPClient) SendMessage(msg *Message) error {
	c.connMux.RLock()
	conn := c.conn
	connected := c.connected
	c.connMux.RUnlock()
	
	if !connected || conn == nil {
		return fmt.Errorf("not connected to server")
	}
	
	data, err := msg.ToJSON()
	if err != nil {
		c.statsMux.Lock()
		c.stats.Errors++
		c.statsMux.Unlock()
		return fmt.Errorf("failed to serialize message: %v", err)
	}
	
	conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
	err = conn.WriteMessage(websocket.TextMessage, data)
	
	if err == nil {
		c.statsMux.Lock()
		c.stats.MessagesSent++
		c.stats.BytesSent += int64(len(data))
		c.stats.LastMessageTime = time.Now()
		c.statsMux.Unlock()
	} else {
		c.statsMux.Lock()
		c.stats.Errors++
		c.statsMux.Unlock()
	}
	
	return err
}

// IsConnected returns true if connected to server
func (c *MCPClient) IsConnected() bool {
	c.connMux.RLock()
	defer c.connMux.RUnlock()
	return c.connected
}

// readPump handles reading messages from server
func (c *MCPClient) readPump() {
	defer func() {
		c.connMux.Lock()
		c.connected = false
		if c.conn != nil {
			c.conn.Close()
		}
		c.connMux.Unlock()
	}()
	
	for {
		select {
		case <-c.ctx.Done():
			return
		default:
			c.connMux.RLock()
			conn := c.conn
			c.connMux.RUnlock()
			
			if conn == nil {
				return
			}
			
			conn.SetReadDeadline(time.Now().Add(60 * time.Second))
			
			_, data, err := conn.ReadMessage()
			if err != nil {
				if websocket.IsUnexpectedCloseError(err, websocket.CloseGoingAway, websocket.CloseAbnormalClosure) {
					c.logger.WithError(err).Error("WebSocket read error")
				}
				
				c.statsMux.Lock()
				c.stats.Errors++
				c.statsMux.Unlock()
				
				if c.reconnectCount < c.maxReconnects {
					go c.attemptReconnect()
				}
				return
			}
			
			c.statsMux.Lock()
			c.stats.MessagesReceived++
			c.stats.BytesReceived += int64(len(data))
			c.stats.LastMessageTime = time.Now()
			c.statsMux.Unlock()
			
			var msg Message
			if err := json.Unmarshal(data, &msg); err != nil {
				c.logger.WithError(err).Error("Failed to unmarshal message")
				continue
			}
			
			if err := msg.Validate(); err != nil {
				c.logger.WithError(err).Error("Invalid message received")
				continue
			}
			
			if handler, exists := c.handlers[msg.Type]; exists {
				if err := handler(nil, &msg); err != nil {
					c.logger.WithError(err).Error("Error handling message")
					c.statsMux.Lock()
					c.stats.Errors++
					c.statsMux.Unlock()
				}
			}
		}
	}
}

// writePump handles sending heartbeats and keepalives
func (c *MCPClient) writePump() {
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()
	
	for {
		select {
		case <-c.ctx.Done():
			return
		case <-ticker.C:
			if !c.IsConnected() {
				continue
			}
			
			heartbeat := NewMessage(MessageHeartbeat, c.clientID)
			heartbeat.SetPayload("timestamp", time.Now().Unix())
			heartbeat.SetPayload("status", "alive")
			
			if err := c.SendMessage(heartbeat); err != nil {
				c.logger.WithError(err).Debug("Failed to send heartbeat")
			}
		}
	}
}

// AutoReconnect enables automatic reconnection
func (c *MCPClient) AutoReconnect(interval time.Duration) {
	c.reconnectDelay = interval
	go c.reconnectMonitor()
}

// reconnectMonitor monitors connection and triggers reconnection
func (c *MCPClient) reconnectMonitor() {
	ticker := time.NewTicker(c.reconnectDelay)
	defer ticker.Stop()
	
	for {
		select {
		case <-c.ctx.Done():
			return
		case <-ticker.C:
			if !c.IsConnected() && c.reconnectCount < c.maxReconnects {
				c.logger.Info("Connection lost, attempting to reconnect...")
				go c.attemptReconnect()
			}
		}
	}
}

// attemptReconnect attempts to reconnect to server
func (c *MCPClient) attemptReconnect() {
	c.reconnectMux.Lock()
	defer c.reconnectMux.Unlock()
	
	if c.IsConnected() {
		return
	}
	
	c.reconnectCount++
	c.logger.WithField("attempt", c.reconnectCount).Info("Attempting to reconnect")
	
	time.Sleep(c.reconnectDelay)
	
	if err := c.Connect(); err != nil {
		c.logger.WithError(err).Warn("Reconnection failed")
		
		if c.reconnectCount >= c.maxReconnects {
			c.logger.Error("Maximum reconnection attempts reached")
			return
		}
		
		c.reconnectDelay *= 2
		if c.reconnectDelay > 60*time.Second {
			c.reconnectDelay = 60 * time.Second
		}
	} else {
		c.logger.Info("Successfully reconnected to server")
		c.reconnectCount = 0
		c.reconnectDelay = 5 * time.Second
		
		c.statsMux.Lock()
		c.stats.ReconnectCount++
		c.statsMux.Unlock()
	}
}