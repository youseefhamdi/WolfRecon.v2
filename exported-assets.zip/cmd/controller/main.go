package main

import (
	"bufio"
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"os/signal"
	"runtime"
	"strings"
	"sync"
	"syscall"
	"time"
	
	"wolf-recon-mcp/internal/mcp"
	"wolf-recon-mcp/internal/models"
	"wolf-recon-mcp/pkg/utils"
	"github.com/sirupsen/logrus"
	"github.com/google/uuid"
)

var (
	version   = "2.5"
	buildDate = "unknown"
	
	// Command line flags
	addr      = flag.String("addr", "0.0.0.0:8080", "Server address")
	logLevel  = flag.String("log", "info", "Log level (debug, info, warn, error)")
	logFormat = flag.String("log-format", "text", "Log format (text, json)")
	config    = flag.String("config", "configs/controller.yaml", "Configuration file")
	daemon    = flag.Bool("daemon", false, "Run in daemon mode")
)

// Controller represents the MCP controller
type Controller struct {
	server   *mcp.Server
	agents   map[string]*models.AgentInfo
	tasks    map[string]*models.Task
	results  map[string]*models.TaskResult
	mutex    sync.RWMutex
	logger   *logrus.Logger
	ctx      context.Context
	cancel   context.CancelFunc
	startTime time.Time
}

func main() {
	flag.Parse()
	
	// Initialize logger
	logger := utils.NewLogger(*logLevel)
	if *logFormat == "json" {
		logger.SetFormatter(&logrus.JSONFormatter{})
	}
	
	// Print banner and system info
	utils.PrintControllerBanner()
	utils.PrintSystemInfo()
	
	// Display configuration
	fmt.Printf("📋 Controller Configuration:\n")
	fmt.Printf("   Address: %s\n", *addr)
	fmt.Printf("   Log Level: %s\n", *logLevel)
	fmt.Printf("   Version: %s\n", version)
	fmt.Printf("   Build Date: %s\n", buildDate)
	fmt.Println()
	
	// Create controller
	controller := NewController(*addr, logger)
	
	// Setup signal handling
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
	
	// Start controller
	go func() {
		logger.Info("Starting Wolf Recon MCP Controller")
		if err := controller.Start(); err != nil {
			logger.Fatalf("Failed to start controller: %v", err)
		}
	}()
	
	// Start background services
	go controller.taskScheduler()
	go controller.agentMonitor()
	
	if !*daemon {
		utils.PrintWelcomeMessage("controller")
		fmt.Println("🎮 Interactive CLI enabled. Starting command interface...")
		fmt.Println()
		
		// Start interactive CLI
		go runInteractiveCLI(controller, logger)
	}
	
	// Wait for shutdown signal
	<-sigChan
	logger.Info("Received shutdown signal, stopping controller...")
	controller.Stop()
	logger.Info("Controller stopped successfully")
}

// NewController creates a new controller instance
func NewController(addr string, logger *logrus.Logger) *Controller {
	ctx, cancel := context.WithCancel(context.Background())
	
	controller := &Controller{
		agents:   make(map[string]*models.AgentInfo),
		tasks:    make(map[string]*models.Task),
		results:  make(map[string]*models.TaskResult),
		logger:   logger,
		ctx:      ctx,
		cancel:   cancel,
		startTime: time.Now(),
	}
	
	// Create MCP server
	server := mcp.NewServer(addr, logger)
	
	// Register message handlers
	server.RegisterHandler(mcp.MessageHeartbeat, controller.handleHeartbeat)
	server.RegisterHandler(mcp.MessageStatusUpdate, controller.handleAgentStatus)
	server.RegisterHandler(mcp.MessageTaskResult, controller.handleTaskResult)
	server.RegisterHandler(mcp.MessageTaskProgress, controller.handleTaskProgress)
	server.RegisterHandler(mcp.MessagePing, controller.handlePing)
	
	controller.server = server
	return controller
}

// Start starts the controller
func (c *Controller) Start() error {
	c.logger.Info("Starting MCP controller server")
	return c.server.Start()
}

// Stop stops the controller
func (c *Controller) Stop() {
	c.logger.Info("Stopping controller...")
	c.server.Stop()
	c.cancel()
}

// Message handlers

func (c *Controller) handleHeartbeat(client *mcp.Client, msg *mcp.Message) error {
	c.logger.WithField("agent_id", msg.From).Debug("Received heartbeat")
	
	c.mutex.Lock()
	if agent, exists := c.agents[msg.From]; exists {
		agent.LastSeen = time.Now()
	}
	c.mutex.Unlock()
	
	return nil
}

func (c *Controller) handleAgentStatus(client *mcp.Client, msg *mcp.Message) error {
	payload, exists := msg.GetPayload("agent_info")
	if !exists {
		return fmt.Errorf("no agent_info in status update")
	}
	
	data, err := json.Marshal(payload)
	if err != nil {
		return fmt.Errorf("failed to marshal agent info: %v", err)
	}
	
	var statusPayload mcp.AgentStatusPayload
	if err := json.Unmarshal(data, &statusPayload); err != nil {
		return fmt.Errorf("failed to unmarshal agent status: %v", err)
	}
	
	// Update agent information
	c.mutex.Lock()
	agent := &models.AgentInfo{
		ID:             statusPayload.AgentID,
		Name:           statusPayload.Name,
		Status:         models.AgentStatus(statusPayload.Status),
		Version:        statusPayload.Version,
		Capabilities:   statusPayload.Capabilities,
		MaxTasks:       statusPayload.MaxTasks,
		CurrentTasks:   statusPayload.CurrentTasks,
		CompletedTasks: statusPayload.CompletedTasks,
		FailedTasks:    statusPayload.FailedTasks,
		LastSeen:       time.Now(),
		Platform:       statusPayload.Platform,
		Architecture:   statusPayload.Architecture,
		Tags:           statusPayload.Tags,
	}
	
	if _, exists := c.agents[agent.ID]; !exists {
		agent.ConnectedAt = time.Now()
		c.logger.WithFields(logrus.Fields{
			"agent_id": agent.ID,
			"name":     agent.Name,
		}).Info("New agent registered")
	}
	
	c.agents[agent.ID] = agent
	c.mutex.Unlock()
	
	return nil
}

func (c *Controller) handleTaskResult(client *mcp.Client, msg *mcp.Message) error {
	payload, exists := msg.GetPayload("result")
	if !exists {
		return fmt.Errorf("no result in task result message")
	}
	
	data, err := json.Marshal(payload)
	if err != nil {
		return fmt.Errorf("failed to marshal task result: %v", err)
	}
	
	var resultPayload mcp.TaskResultPayload
	if err := json.Unmarshal(data, &resultPayload); err != nil {
		return fmt.Errorf("failed to unmarshal task result: %v", err)
	}
	
	c.mutex.Lock()
	defer c.mutex.Unlock()
	
	// Update task status
	if task, exists := c.tasks[resultPayload.TaskID]; exists {
		if resultPayload.Status == "completed" {
			task.Status = models.TaskCompleted
			now := time.Now()
			task.CompletedAt = &now
			
			// Store result
			result := &models.TaskResult{
				Subdomains: resultPayload.Subdomains,
				IPs:        resultPayload.IPs,
				URLs:       resultPayload.URLs,
				Count:      resultPayload.Count,
				Duration:   time.Duration(resultPayload.Duration) * time.Millisecond,
				OutputFile: resultPayload.OutputFile,
				Metadata:   resultPayload.Metadata,
			}
			
			c.results[resultPayload.TaskID] = result
			task.Result = result
			
			c.logger.WithFields(logrus.Fields{
				"task_id": resultPayload.TaskID,
				"count":   resultPayload.Count,
			}).Info("Task completed successfully")
		} else if resultPayload.Status == "failed" {
			task.Status = models.TaskFailed
			task.Error = resultPayload.Error
			now := time.Now()
			task.CompletedAt = &now
			
			c.logger.WithFields(logrus.Fields{
				"task_id": resultPayload.TaskID,
				"error":   resultPayload.Error,
			}).Error("Task failed")
		}
		
		// Update agent task count
		if agent, exists := c.agents[task.AgentID]; exists {
			if agent.CurrentTasks > 0 {
				agent.CurrentTasks--
			}
			if task.Status == models.TaskCompleted {
				agent.CompletedTasks++
			} else if task.Status == models.TaskFailed {
				agent.FailedTasks++
			}
		}
	}
	
	return nil
}

func (c *Controller) handleTaskProgress(client *mcp.Client, msg *mcp.Message) error {
	payload, exists := msg.GetPayload("progress")
	if !exists {
		return fmt.Errorf("no progress in task progress message")
	}
	
	data, err := json.Marshal(payload)
	if err != nil {
		return fmt.Errorf("failed to marshal task progress: %v", err)
	}
	
	var progressPayload mcp.TaskProgressPayload
	if err := json.Unmarshal(data, &progressPayload); err != nil {
		return fmt.Errorf("failed to unmarshal task progress: %v", err)
	}
	
	c.mutex.Lock()
	if task, exists := c.tasks[progressPayload.TaskID]; exists {
		task.Progress = progressPayload.Progress
		if task.Status == models.TaskPending {
			task.Status = models.TaskRunning
			now := time.Now()
			task.StartedAt = &now
		}
	}
	c.mutex.Unlock()
	
	c.logger.WithFields(logrus.Fields{
		"task_id":  progressPayload.TaskID,
		"progress": progressPayload.Progress,
		"stage":    progressPayload.Stage,
	}).Debug("Task progress update")
	
	return nil
}

func (c *Controller) handlePing(client *mcp.Client, msg *mcp.Message) error {
	response := mcp.NewMessage(mcp.MessagePong, "controller")
	response.ResponseTo = msg.ID
	response.SetPayload("timestamp", time.Now().Unix())
	
	return client.SendMessage(response)
}

// Task management

// AddTargets adds targets for scanning
func (c *Controller) AddTargets(targets []string, taskTypes []models.TaskType) error {
	c.mutex.Lock()
	defer c.mutex.Unlock()
	
	for _, target := range targets {
		for _, taskType := range taskTypes {
			task := models.NewTask(taskType, target, 300) // 5 minute timeout
			c.tasks[task.ID] = task
			
			c.logger.WithFields(logrus.Fields{
				"task_id": task.ID,
				"type":    task.Type,
				"target":  task.Target,
			}).Info("Task queued")
		}
	}
	
	return nil
}

// Background services

func (c *Controller) taskScheduler() {
	ticker := time.NewTicker(2 * time.Second)
	defer ticker.Stop()
	
	for {
		select {
		case <-c.ctx.Done():
			return
		case <-ticker.C:
			c.schedulePendingTasks()
		}
	}
}

func (c *Controller) schedulePendingTasks() {
	c.mutex.Lock()
	defer c.mutex.Unlock()
	
	// Find pending tasks
	var pendingTasks []*models.Task
	for _, task := range c.tasks {
		if task.Status == models.TaskPending {
			pendingTasks = append(pendingTasks, task)
		}
	}
	
	if len(pendingTasks) == 0 {
		return
	}
	
	// Find available agents
	var availableAgents []*models.AgentInfo
	for _, agent := range c.agents {
		if agent.IsAvailable() && agent.IsHealthy() {
			availableAgents = append(availableAgents, agent)
		}
	}
	
	if len(availableAgents) == 0 {
		return
	}
	
	// Assign tasks to agents
	for i, task := range pendingTasks {
		if i >= len(availableAgents) {
			break
		}
		
		agent := availableAgents[i]
		if !agent.SupportsTask(task.Type) {
			continue
		}
		
		// Assign task to agent
		task.AgentID = agent.ID
		task.Status = models.TaskRunning
		now := time.Now()
		task.StartedAt = &now
		
		agent.CurrentTasks++
		
		// Send task assignment
		assignment := mcp.TaskAssignment{
			TaskID:  task.ID,
			Type:    string(task.Type),
			Target:  task.Target,
			Timeout: task.Timeout,
		}
		
		msg := mcp.NewMessage(mcp.MessageTaskAssignment, "controller")
		msg.To = agent.ID
		msg.SetPayload("task", assignment)
		
		if err := c.server.SendToClient(agent.ID, msg); err != nil {
			c.logger.WithError(err).Error("Failed to send task assignment")
			task.Status = models.TaskPending
			task.AgentID = ""
			agent.CurrentTasks--
		} else {
			c.logger.WithFields(logrus.Fields{
				"task_id":  task.ID,
				"agent_id": agent.ID,
			}).Info("Task assigned to agent")
		}
	}
}

func (c *Controller) agentMonitor() {
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()
	
	for {
		select {
		case <-c.ctx.Done():
			return
		case <-ticker.C:
			c.cleanupDeadAgents()
		}
	}
}

func (c *Controller) cleanupDeadAgents() {
	c.mutex.Lock()
	defer c.mutex.Unlock()
	
	cutoff := time.Now().Add(-2 * time.Minute)
	var deadAgents []string
	
	for id, agent := range c.agents {
		if agent.LastSeen.Before(cutoff) {
			deadAgents = append(deadAgents, id)
		}
	}
	
	for _, agentID := range deadAgents {
		c.logger.WithField("agent_id", agentID).Warn("Removing dead agent")
		delete(c.agents, agentID)
		
		// Reset tasks assigned to this agent
		for _, task := range c.tasks {
			if task.AgentID == agentID && task.Status == models.TaskRunning {
				task.Status = models.TaskPending
				task.AgentID = ""
				task.StartedAt = nil
			}
		}
	}
}

// Status and information methods

func (c *Controller) GetStatus() map[string]interface{} {
	c.mutex.RLock()
	defer c.mutex.RUnlock()
	
	// Count task statuses
	tasksByStatus := make(map[string]int)
	for _, task := range c.tasks {
		tasksByStatus[string(task.Status)]++
	}
	
	// Count agent statuses
	agentsByStatus := make(map[string]int)
	for _, agent := range c.agents {
		agentsByStatus[string(agent.Status)]++
	}
	
	return map[string]interface{}{
		"controller": map[string]interface{}{
			"version":    version,
			"build_date": buildDate,
			"uptime":     time.Since(c.startTime).String(),
		},
		"agents": map[string]interface{}{
			"total":     len(c.agents),
			"online":    agentsByStatus["online"],
			"busy":      agentsByStatus["busy"],
			"by_status": agentsByStatus,
		},
		"tasks": map[string]interface{}{
			"total":     len(c.tasks),
			"by_status": tasksByStatus,
		},
		"results": len(c.results),
	}
}

func (c *Controller) GetAgents() []*models.AgentInfo {
	c.mutex.RLock()
	defer c.mutex.RUnlock()
	
	agents := make([]*models.AgentInfo, 0, len(c.agents))
	for _, agent := range c.agents {
		agents = append(agents, agent)
	}
	return agents
}

func (c *Controller) GetTasks() []*models.Task {
	c.mutex.RLock()
	defer c.mutex.RUnlock()
	
	tasks := make([]*models.Task, 0, len(c.tasks))
	for _, task := range c.tasks {
		tasks = append(tasks, task)
	}
	return tasks
}

func (c *Controller) GetResults() map[string]*models.TaskResult {
	c.mutex.RLock()
	defer c.mutex.RUnlock()
	
	results := make(map[string]*models.TaskResult)
	for id, result := range c.results {
		results[id] = result
	}
	return results
}

// Interactive CLI

func runInteractiveCLI(ctrl *Controller, logger *logrus.Logger) {
	reader := bufio.NewScanner(os.Stdin)
	
	fmt.Println("🎮 Wolf Recon Controller Interactive CLI")
	fmt.Println("========================================")
	fmt.Print("wolf-recon> ")
	
	for reader.Scan() {
		command := strings.TrimSpace(reader.Text())
		if command == "" {
			fmt.Print("wolf-recon> ")
			continue
		}
		
		parts := strings.Fields(command)
		if len(parts) == 0 {
			fmt.Print("wolf-recon> ")
			continue
		}
		
		switch parts[0] {
		case "help", "h":
			printHelp()
		case "status", "stat":
			showStatus(ctrl)
		case "agents", "agent":
			showAgents(ctrl)
		case "tasks", "task":
			showTasks(ctrl)
		case "scan", "s":
			if len(parts) < 2 {
				fmt.Println("❌ Usage: scan <target1> [target2] ...")
			} else {
				startScan(ctrl, parts[1:])
			}
		case "results", "result", "r":
			showResults(ctrl)
		case "export":
			if len(parts) < 2 {
				fmt.Println("❌ Usage: export <format> [filename]")
			} else {
				exportResults(ctrl, parts[1], getOptionalArg(parts, 2))
			}
		case "clear", "cls":
			utils.ClearScreen()
		case "version", "ver", "v":
			showVersion()
		case "quit", "exit", "q":
			fmt.Println("👋 Goodbye!")
			os.Exit(0)
		default:
			fmt.Printf("❓ Unknown command: %s\n", parts[0])
			fmt.Println("💡 Type 'help' for available commands")
		}
		
		fmt.Print("wolf-recon> ")
	}
}

func printHelp() {
	fmt.Println("🎮 Wolf Recon Controller - Available Commands")
	fmt.Println("===========================================")
	fmt.Printf("  %-13s %s\n", "scan <targets>", "Start reconnaissance scan")
	fmt.Printf("  %-13s %s\n", "status", "Show controller status")
	fmt.Printf("  %-13s %s\n", "agents", "List connected agents")
	fmt.Printf("  %-13s %s\n", "tasks", "Show tasks status")
	fmt.Printf("  %-13s %s\n", "results", "Show scan results")
	fmt.Printf("  %-13s %s\n", "export <fmt>", "Export results (json, csv, txt)")
	fmt.Printf("  %-13s %s\n", "clear", "Clear screen")
	fmt.Printf("  %-13s %s\n", "version", "Show version")
	fmt.Printf("  %-13s %s\n", "help", "Show this help")
	fmt.Printf("  %-13s %s\n", "quit", "Exit controller")
	fmt.Println()
}

func showStatus(ctrl *Controller) {
	status := ctrl.GetStatus()
	fmt.Println()
	utils.PrintHeader("Controller Status")
	
	if controller, ok := status["controller"].(map[string]interface{}); ok {
		fmt.Printf("🎮 Controller: v%s\n", controller["version"])
		fmt.Printf("⏰ Uptime: %s\n", controller["uptime"])
	}
	
	if agents, ok := status["agents"].(map[string]interface{}); ok {
		fmt.Printf("🤖 Agents: %d total, %d online\n", 
			agents["total"], agents["online"])
	}
	
	if tasks, ok := status["tasks"].(map[string]interface{}); ok {
		fmt.Printf("📋 Tasks: %d total\n", tasks["total"])
	}
	
	fmt.Printf("📊 Results: %d collections\n", status["results"])
	fmt.Println()
}

func showAgents(ctrl *Controller) {
	agents := ctrl.GetAgents()
	fmt.Println()
	utils.PrintHeader("Connected Agents")
	
	if len(agents) == 0 {
		fmt.Println("❌ No agents connected")
		fmt.Println()
		return
	}
	
	fmt.Printf("%-12s %-20s %-8s %-12s\n", "ID", "Name", "Status", "Tasks")
	fmt.Println(strings.Repeat("-", 60))
	
	for _, agent := range agents {
		agentID := agent.ID
		if len(agentID) > 12 {
			agentID = agentID[:8] + "..."
		}
		
		fmt.Printf("%-12s %-20s %-8s %d/%-10d\n",
			agentID, agent.Name, agent.Status,
			agent.CurrentTasks, agent.MaxTasks)
	}
	fmt.Println()
}

func showTasks(ctrl *Controller) {
	tasks := ctrl.GetTasks()
	fmt.Println()
	utils.PrintHeader("Tasks Overview")
	
	if len(tasks) == 0 {
		fmt.Println("📝 No tasks found")
		fmt.Println()
		return
	}
	
	statusCounts := make(map[models.TaskStatus]int)
	for _, task := range tasks {
		statusCounts[task.Status]++
	}
	
	fmt.Printf("📊 Total Tasks: %d\n\n", len(tasks))
	for status, count := range statusCounts {
		fmt.Printf("   %s: %d\n", strings.Title(string(status)), count)
	}
	fmt.Println()
}

func startScan(ctrl *Controller, targets []string) {
	taskTypes := []models.TaskType{
		models.TaskSubfinder,
		models.TaskAssetfinder,
		models.TaskAmass,
	}
	
	fmt.Printf("🎯 Starting scan for %d targets...\n", len(targets))
	
	err := ctrl.AddTargets(targets, taskTypes)
	if err != nil {
		fmt.Printf("❌ Error starting scan: %v\n", err)
		return
	}
	
	fmt.Printf("✅ Queued %d tasks for execution\n", len(targets)*len(taskTypes))
	fmt.Println()
}

func showResults(ctrl *Controller) {
	results := ctrl.GetResults()
	fmt.Println()
	utils.PrintHeader("Scan Results")
	
	if len(results) == 0 {
		fmt.Println("📝 No results available yet")
		fmt.Println()
		return
	}
	
	totalSubdomains := 0
	for _, result := range results {
		totalSubdomains += len(result.Subdomains)
	}
	
	fmt.Printf("📊 Summary:\n")
	fmt.Printf("   • Total Results: %d scans\n", len(results))
	fmt.Printf("   • Subdomains Found: %d\n", totalSubdomains)
	fmt.Println()
}

func exportResults(ctrl *Controller, format, filename string) {
	results := ctrl.GetResults()
	
	if len(results) == 0 {
		fmt.Println("❌ No results to export")
		return
	}
	
	if filename == "" {
		timestamp := time.Now().Format("20060102-150405")
		filename = fmt.Sprintf("wolf-recon-results-%s.%s", timestamp, format)
	}
	
	fmt.Printf("📤 Exporting %d results to %s...\n", len(results), filename)
	
	switch format {
	case "json":
		exportJSON(results, filename)
	case "csv":
		exportCSV(results, filename)
	case "txt":
		exportText(results, filename)
	default:
		fmt.Printf("❌ Unsupported format: %s\n", format)
		return
	}
	
	fmt.Printf("✅ Results exported to %s\n", filename)
}

func exportJSON(results map[string]*models.TaskResult, filename string) {
	data := map[string]interface{}{
		"timestamp": time.Now().Format(time.RFC3339),
		"results":   results,
	}
	
	file, err := os.Create(filename)
	if err != nil {
		fmt.Printf("❌ Failed to create file: %v\n", err)
		return
	}
	defer file.Close()
	
	encoder := json.NewEncoder(file)
	encoder.SetIndent("", "  ")
	encoder.Encode(data)
}

func exportCSV(results map[string]*models.TaskResult, filename string) {
	file, err := os.Create(filename)
	if err != nil {
		fmt.Printf("❌ Failed to create file: %v\n", err)
		return
	}
	defer file.Close()
	
	file.WriteString("TaskID,Subdomain,Count,Duration\n")
	
	for taskID, result := range results {
		for _, subdomain := range result.Subdomains {
			file.WriteString(fmt.Sprintf("%s,%s,%d,%.2f\n", 
				taskID, subdomain, result.Count, result.Duration.Seconds()))
		}
	}
}

func exportText(results map[string]*models.TaskResult, filename string) {
	file, err := os.Create(filename)
	if err != nil {
		fmt.Printf("❌ Failed to create file: %v\n", err)
		return
	}
	defer file.Close()
	
	file.WriteString(fmt.Sprintf("Wolf Recon MCP Results Export\n"))
	file.WriteString(fmt.Sprintf("Generated: %s\n\n", time.Now().Format("2006-01-02 15:04:05")))
	
	for taskID, result := range results {
		file.WriteString(fmt.Sprintf("Task ID: %s\n", taskID))
		file.WriteString(fmt.Sprintf("Count: %d\n", result.Count))
		file.WriteString(fmt.Sprintf("Duration: %s\n", result.Duration))
		
		if len(result.Subdomains) > 0 {
			file.WriteString("Subdomains:\n")
			for _, subdomain := range result.Subdomains {
				file.WriteString(fmt.Sprintf("  %s\n", subdomain))
			}
		}
		
		file.WriteString("\n" + strings.Repeat("-", 50) + "\n\n")
	}
}

func showVersion() {
	fmt.Printf("Wolf Recon MCP v%s\n", version)
	fmt.Printf("Build Date: %s\n", buildDate)
	fmt.Printf("Go Version: %s\n", runtime.Version())
}

func getOptionalArg(parts []string, index int) string {
	if index < len(parts) {
		return parts[index]
	}
	return ""
}